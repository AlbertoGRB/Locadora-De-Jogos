﻿namespace Alberto_Gabriel
{
    partial class Frm_Locadora
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_Locadora));
            this.BottomToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.TopToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.RightToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.LeftToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.ContentPanel = new System.Windows.Forms.ToolStripContentPanel();
            this.menuStrip_Locadora = new System.Windows.Forms.MenuStrip();
            this.toolStripTextBoxClientes = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripTextBoxGeneros = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripTextBoxJogos = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemEmpréstimos = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemDevoluções = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripTextBoxSair = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip_Locadora.SuspendLayout();
            this.SuspendLayout();
            // 
            // BottomToolStripPanel
            // 
            this.BottomToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.BottomToolStripPanel.Name = "BottomToolStripPanel";
            this.BottomToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.BottomToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.BottomToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // TopToolStripPanel
            // 
            this.TopToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.TopToolStripPanel.Name = "TopToolStripPanel";
            this.TopToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.TopToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.TopToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // RightToolStripPanel
            // 
            this.RightToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.RightToolStripPanel.Name = "RightToolStripPanel";
            this.RightToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.RightToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.RightToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // LeftToolStripPanel
            // 
            this.LeftToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.LeftToolStripPanel.Name = "LeftToolStripPanel";
            this.LeftToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.LeftToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.LeftToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // ContentPanel
            // 
            this.ContentPanel.Size = new System.Drawing.Size(799, 448);
            // 
            // menuStrip_Locadora
            // 
            this.menuStrip_Locadora.AutoSize = false;
            this.menuStrip_Locadora.BackColor = System.Drawing.Color.Black;
            this.menuStrip_Locadora.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip_Locadora.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripTextBoxClientes,
            this.toolStripTextBoxGeneros,
            this.toolStripTextBoxJogos,
            this.toolStripMenuItem4,
            this.toolStripTextBoxSair});
            this.menuStrip_Locadora.Location = new System.Drawing.Point(0, 0);
            this.menuStrip_Locadora.Name = "menuStrip_Locadora";
            this.menuStrip_Locadora.Size = new System.Drawing.Size(767, 31);
            this.menuStrip_Locadora.TabIndex = 9;
            this.menuStrip_Locadora.Text = "menuStrip1";
            // 
            // toolStripTextBoxClientes
            // 
            this.toolStripTextBoxClientes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold);
            this.toolStripTextBoxClientes.ForeColor = System.Drawing.Color.DarkCyan;
            this.toolStripTextBoxClientes.Name = "toolStripTextBoxClientes";
            this.toolStripTextBoxClientes.Size = new System.Drawing.Size(88, 27);
            this.toolStripTextBoxClientes.Text = "Clientes";
            this.toolStripTextBoxClientes.Click += new System.EventHandler(this.toolStripTextBoxClientes_Click);
            // 
            // toolStripTextBoxGeneros
            // 
            this.toolStripTextBoxGeneros.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold);
            this.toolStripTextBoxGeneros.ForeColor = System.Drawing.Color.DarkCyan;
            this.toolStripTextBoxGeneros.Name = "toolStripTextBoxGeneros";
            this.toolStripTextBoxGeneros.Size = new System.Drawing.Size(92, 27);
            this.toolStripTextBoxGeneros.Text = "Gêneros";
            this.toolStripTextBoxGeneros.Click += new System.EventHandler(this.toolStripTextBoxGeneros_Click);
            // 
            // toolStripTextBoxJogos
            // 
            this.toolStripTextBoxJogos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold);
            this.toolStripTextBoxJogos.ForeColor = System.Drawing.Color.DarkCyan;
            this.toolStripTextBoxJogos.Name = "toolStripTextBoxJogos";
            this.toolStripTextBoxJogos.Size = new System.Drawing.Size(71, 27);
            this.toolStripTextBoxJogos.Text = "Jogos";
            this.toolStripTextBoxJogos.Click += new System.EventHandler(this.toolStripTextBoxJogos_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.BackColor = System.Drawing.Color.Black;
            this.toolStripMenuItem4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItemEmpréstimos,
            this.ToolStripMenuItemDevoluções});
            this.toolStripMenuItem4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold);
            this.toolStripMenuItem4.ForeColor = System.Drawing.Color.DarkCyan;
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(110, 27);
            this.toolStripMenuItem4.Text = "Operações";
            // 
            // ToolStripMenuItemEmpréstimos
            // 
            this.ToolStripMenuItemEmpréstimos.BackColor = System.Drawing.Color.Black;
            this.ToolStripMenuItemEmpréstimos.ForeColor = System.Drawing.Color.DarkCyan;
            this.ToolStripMenuItemEmpréstimos.Name = "ToolStripMenuItemEmpréstimos";
            this.ToolStripMenuItemEmpréstimos.Size = new System.Drawing.Size(224, 26);
            this.ToolStripMenuItemEmpréstimos.Text = "Empréstimos";
            this.ToolStripMenuItemEmpréstimos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ToolStripMenuItemEmpréstimos.Click += new System.EventHandler(this.ToolStripMenuItemEmpréstimos_Click);
            // 
            // ToolStripMenuItemDevoluções
            // 
            this.ToolStripMenuItemDevoluções.BackColor = System.Drawing.Color.Black;
            this.ToolStripMenuItemDevoluções.ForeColor = System.Drawing.Color.DarkCyan;
            this.ToolStripMenuItemDevoluções.Name = "ToolStripMenuItemDevoluções";
            this.ToolStripMenuItemDevoluções.Size = new System.Drawing.Size(224, 26);
            this.ToolStripMenuItemDevoluções.Text = "Devoluções";
            this.ToolStripMenuItemDevoluções.Click += new System.EventHandler(this.ToolStripMenuItemDevoluções_Click);
            // 
            // toolStripTextBoxSair
            // 
            this.toolStripTextBoxSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold);
            this.toolStripTextBoxSair.ForeColor = System.Drawing.Color.DarkCyan;
            this.toolStripTextBoxSair.Name = "toolStripTextBoxSair";
            this.toolStripTextBoxSair.Size = new System.Drawing.Size(55, 27);
            this.toolStripTextBoxSair.Text = "Sair";
            this.toolStripTextBoxSair.Click += new System.EventHandler(this.toolStripTextBoxSair_Click);
            // 
            // Frm_Locadora
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(767, 519);
            this.Controls.Add(this.menuStrip_Locadora);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.Name = "Frm_Locadora";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds;
            this.Text = "Locadora";
            this.Load += new System.EventHandler(this.Frm_Locadora_Load);
            this.menuStrip_Locadora.ResumeLayout(false);
            this.menuStrip_Locadora.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolStripPanel BottomToolStripPanel;
        private System.Windows.Forms.ToolStripPanel TopToolStripPanel;
        private System.Windows.Forms.ToolStripPanel RightToolStripPanel;
        private System.Windows.Forms.ToolStripPanel LeftToolStripPanel;
        private System.Windows.Forms.ToolStripContentPanel ContentPanel;
        private System.Windows.Forms.MenuStrip menuStrip_Locadora;
        private System.Windows.Forms.ToolStripMenuItem toolStripTextBoxClientes;
        private System.Windows.Forms.ToolStripMenuItem toolStripTextBoxGeneros;
        private System.Windows.Forms.ToolStripMenuItem toolStripTextBoxJogos;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemEmpréstimos;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemDevoluções;
        private System.Windows.Forms.ToolStripMenuItem toolStripTextBoxSair;
    }
}

