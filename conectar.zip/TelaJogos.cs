﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Alberto_Gabriel
{
    public partial class Frm_Jogos : Form
    {
        public Frm_Jogos()
        {
            InitializeComponent();
        }
        private void ToolStripMenuItem_Cadastrar_Click(object sender, EventArgs e)
        {
            Limpa_Campos();
            txt_Nome.Focus();
            Escolher_Genero.Items.Clear();
            MySqlConnection conexao = conectar.fazer_conexao();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = conexao;
            try
            {
                conexao.Open();
                cmd.CommandText = "Select * from generos order by Descricao";
                MySqlDataReader resultado = cmd.ExecuteReader();
                if (resultado.HasRows)
                {
                    while (resultado.Read())
                    {
                        Escolher_Genero.Items.Add(resultado["Descricao"].ToString());
                    }
                }
                resultado.Close();

            }
            catch (MySqlException err)
            {
                MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0);
            }
        }
        private void ToolStripMenuItem_Alterar_Click(object sender, EventArgs e)
        {
            txt_Nome.Focus();
            MySqlConnection conexao = conectar.fazer_conexao();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = conexao;
            try
            {
                conexao.Open();
                cmd.CommandText = "Select * from jogos order by Nome limit 1";
                MySqlDataReader resultado = cmd.ExecuteReader();
                if (resultado.HasRows)
                {
                    resultado.Read();
                    txt_ID.Text = resultado["ID"].ToString();
                    txt_Nome.Text = resultado["Nome"].ToString();
                    txt_Desenvolvedor.Text = resultado["Desenvolvedor"].ToString();
                    maskedTextBox_Data_de_Lancamento.Text = resultado["Data_de_Lançamento"].ToString();
                    Escolher_Genero.Text = resultado["Genero"].ToString();
                }
                ChecaBotoes();
                conexao.Close();
            }
            catch (MySqlException err)
            {
                MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0);
            }
        }

        private void ToolStripMenuItem_Procurar_Click(object sender, EventArgs e)
        {
            Frm_ProcurarJogos frm_ProcurarJogos = new Frm_ProcurarJogos();
            frm_ProcurarJogos.ShowDialog();
            if (conectar.nome_busca != "")
            {
                Escolher_Genero.Items.Clear();
                MySqlConnection conexao = conectar.fazer_conexao();
                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = conexao;
                try
                {
                    conexao.Open();
                    cmd.CommandText = "Select * from jogos where Nome like '%" + conectar.nome_busca + "%' order by Nome desc limit 1";
                    MySqlDataReader resultado = cmd.ExecuteReader();
                    if (resultado.HasRows)
                    {
                        resultado.Read();
                        txt_ID.Text = resultado["ID"].ToString();
                        txt_Nome.Text = resultado["Nome"].ToString();
                        txt_Desenvolvedor.Text = resultado["Desenvolvedor"].ToString();
                        maskedTextBox_Data_de_Lancamento.Text = resultado["Data_de_Lançamento"].ToString();
                        try
                        {
                            MySqlConnection conex = conectar.fazer_conexao();
                            conex.Open();
                            cmd.Connection = conex;
                            cmd.CommandText = "Select g.Descricao from generos g, jogos j where g.ID = j.Genero and j.ID = " + txt_ID.Text;
                            MySqlDataReader resp = cmd.ExecuteReader();
                            if (resp.HasRows)
                            {
                                while (resp.Read())
                                {
                                    Escolher_Genero.Items.Add(resp["Descricao"].ToString());
                                }
                            }
                            resp.Close();
                            conex.Close();
                        }
                        catch (MySqlException err)
                        {
                            MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            Environment.Exit(0);
                        }
                    }
                    else
                    {
                        MessageBox.Show("O Jogo " + conectar.nome_busca + " não foi encontrado", "Procurar : Jogos", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    ChecaBotoes();
                    conexao.Close();
                }
                catch (MySqlException err)
                {
                    MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Environment.Exit(0);
                }
            }
        }

        private void ToolStripMenuItem_Excluir_Click(object sender, EventArgs e)
        {
            MySqlConnection conexao = conectar.fazer_conexao();
            try
            {
                conexao.Open();
                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = conexao;
                cmd.CommandText = "Select i.ID_jogo, i.ID_Emprestimo, e.ID, e.Data_de_Devolucao from itens_emprestimo i, emprestimos e where i.ID_Emprestimo = e.ID and e.Data_de_Devolucao < 1 and i.ID_jogo = " + txt_ID.Text;
              
                MySqlDataReader resp = cmd.ExecuteReader();
                if (resp.HasRows)
                {
                    MessageBox.Show("Há um empréstimo com esse jogo \n O jogo não pode ser excluído", "Excluir", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    resp.Close();
                    cmd.CommandText = "Delete from jogos where ID = " + txt_ID.Text;
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("O jogo foi excluído com sucesso", "Excluir", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Limpa_Campos();
                }
                conexao.Close();
                ChecaBotoes();
            }
            catch (MySqlException err)
            {
                MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0);
            }
        }
        private void btn_Salvar_Click(object sender, EventArgs e)
        {
            if (Escolher_Genero.SelectedIndex < 0)
            {
                MessageBox.Show("Selecione o gênero antes de prosseguir", "Salvar : Jogos", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Escolher_Genero.Focus();
            }
            else
            {  
                MySqlConnection conexao = conectar.fazer_conexao();
                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = conexao;
                try
                {
                    conexao.Open();
                    cmd.CommandText = "Select ID from generos where Descricao = '" + Escolher_Genero.SelectedItem + "'";
                    MySqlDataReader resultado = cmd.ExecuteReader();
                    resultado.Read();
                    string id_genero = resultado["ID"].ToString();
                    resultado.Close();
                    if (txt_ID.Text == "")
                    {
                        cmd.CommandText = "Insert into jogos (Nome, Desenvolvedor, Genero, Data_de_Lançamento) values ('" + txt_Nome.Text + "','" + txt_Desenvolvedor.Text + "','" + id_genero + "','" + maskedTextBox_Data_de_Lancamento.Text + "')";
                    }
                    else
                    cmd.CommandText = "Update jogos set Nome = '" + txt_Nome.Text + "', Desenvolvedor = '" + txt_Desenvolvedor.Text + "', Data_de_Lançamento = '" + maskedTextBox_Data_de_Lancamento.Text + "', Genero = '" + id_genero + "' where ID = " + txt_ID.Text;
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Jogo salvo com sucesso!", "Salvar : Jogos", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    conexao.Close();
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Erro: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                try
                {
                    conexao.Open();
                    cmd.CommandText = "Select MAX(ID) from jogos";
                    MySqlDataReader resultado = cmd.ExecuteReader();
                    if (resultado.HasRows)
                    {
                        resultado.Read();
                        txt_ID.Text = resultado["MAX(ID)"].ToString();
                    }
                    conexao.Close();
                }
                catch (MySqlException err)
                {
                    MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Environment.Exit(0);
                }
            }
        }

        private void btn_Sair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btn_Proximo_Click(object sender, EventArgs e)
        {
            Escolher_Genero.Items.Clear();
            MySqlConnection conexao = conectar.fazer_conexao();    
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = conexao;
            try
            {
                conexao.Open();
                cmd.CommandText = "Select * from jogos where Nome > '" + txt_Nome.Text + "' order by nome limit 1";
                MySqlDataReader resultado = cmd.ExecuteReader();
                if (resultado.HasRows)
                {
                    resultado.Read();
                    txt_ID.Text = resultado["ID"].ToString();
                    txt_Nome.Text = resultado["Nome"].ToString();
                    txt_Desenvolvedor.Text = resultado["Desenvolvedor"].ToString();
                    maskedTextBox_Data_de_Lancamento.Text = resultado["Data_de_Lançamento"].ToString();
                    try
                    {
                        MySqlConnection conex = conectar.fazer_conexao();
                        conex.Open();
                        cmd.Connection = conex;
                        cmd.CommandText = "Select g.Descricao from generos g, jogos j where g.ID = j.Genero and j.ID = " + txt_ID.Text;
                        MySqlDataReader resp = cmd.ExecuteReader();
                        if (resp.HasRows)
                        {
                            while (resp.Read())
                            {
                                Escolher_Genero.Items.Add(resp["Descricao"].ToString());
                            }
                        }
                        resp.Close();
                        conex.Close();
                    }
                    catch (MySqlException err)
                    {
                        MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        Environment.Exit(0);
                    }
                } 
                ChecaBotoes();
                conexao.Close();
            }
            catch (MySqlException err)
            {
                MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0);
            }
        }

        private void btn_Anterior_Click(object sender, EventArgs e)
        {
            Escolher_Genero.Items.Clear();
            MySqlConnection conexao = conectar.fazer_conexao();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = conexao;
            try
            {
                conexao.Open();
                cmd.CommandText = "Select * from jogos where Nome < '" + txt_Nome.Text + "' order by nome desc limit 1";
                MySqlDataReader resultado = cmd.ExecuteReader();
                if (resultado.HasRows)
                {
                    resultado.Read();
                    txt_ID.Text = resultado["ID"].ToString();
                    txt_Nome.Text = resultado["Nome"].ToString();
                    txt_Desenvolvedor.Text = resultado["Desenvolvedor"].ToString();
                    maskedTextBox_Data_de_Lancamento.Text = resultado["Data_de_Lançamento"].ToString();
                    try
                    {
                        MySqlConnection conex = conectar.fazer_conexao();
                        conex.Open();
                        cmd.Connection = conex;
                        cmd.CommandText = "Select g.Descricao from generos g, jogos j where g.ID = j.Genero and j.ID = " + txt_ID.Text;
                        MySqlDataReader resp = cmd.ExecuteReader();
                        if (resp.HasRows)
                        {
                            while (resp.Read())
                            {
                                Escolher_Genero.Items.Add(resp["Descricao"].ToString());
                            }
                        }
                        resp.Close();
                        conex.Close();
                    }
                    catch (MySqlException err)
                    {
                        MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        Environment.Exit(0);
                    }
                }
                ChecaBotoes();
                conexao.Close();
            }
            catch (MySqlException err)
            {
                MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0);
            }
        }

        private void Limpa_Campos()
        {
            txt_ID.Text = "";
            txt_Nome.Text = "";
            txt_Desenvolvedor.Text = "";
            maskedTextBox_Data_de_Lancamento.Text = "";
            Escolher_Genero.Text = "";
        }
        
        private void ChecaBotoes()
        {
            MySqlConnection conexao = conectar.fazer_conexao();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = conexao;
            try
            {
                conexao.Open();
                cmd.CommandText = "Select * from jogos order by Nome desc limit 1";
                MySqlDataReader resultado = cmd.ExecuteReader();
                if (resultado.HasRows)
                {
                    resultado.Read();
                    if (resultado["ID"].ToString() == txt_ID.Text)
                    {
                        btn_Proximo.Visible = false;
                    }
                    else
                    {
                        btn_Proximo.Visible = true; 
                    }
                }
                resultado.Close();
                cmd.CommandText = "Select * from jogos order by Nome limit 1";
                resultado = cmd.ExecuteReader();
                if (resultado.HasRows)
                {
                    resultado.Read();
                    if (resultado["ID"].ToString() == txt_ID.Text)
                    {
                        btn_Anterior.Visible = false;
                    }
                    else
                    {
                        btn_Anterior.Visible = true;
                    }
                }
                conexao.Close();
            }
            catch (MySqlException err)
            {
                MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0); 
            }
        }

        private void Frm_Jogos_Load(object sender, EventArgs e)
        {
            Escolher_Genero.Items.Clear();
            MySqlConnection conexao = conectar.fazer_conexao();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = conexao;
            try
            {
                conexao.Open();
                cmd.CommandText = "Select * from jogos where Nome > '" + txt_Nome.Text + "' order by nome limit 1";
                MySqlDataReader resultado = cmd.ExecuteReader();
                if (resultado.HasRows)
                {
                    resultado.Read();
                    txt_ID.Text = resultado["ID"].ToString();
                    txt_Nome.Text = resultado["Nome"].ToString();
                    txt_Desenvolvedor.Text = resultado["Desenvolvedor"].ToString();
                    maskedTextBox_Data_de_Lancamento.Text = resultado["Data_de_Lançamento"].ToString();
                    try
                    {
                        MySqlConnection conex = conectar.fazer_conexao();
                        conex.Open();
                        cmd.Connection = conex; 
                        cmd.CommandText = "Select g.Descricao from generos g, jogos j where g.ID = j.Genero and j.ID = " + txt_ID.Text;
                        MySqlDataReader resp = cmd.ExecuteReader();
                        if (resp.HasRows)
                        {
                            while (resp.Read())
                            {
                                Escolher_Genero.Items.Add(resp["Descricao"].ToString());
                            }
                        }
                        resp.Close();
                        conex.Close();
                    }
                    catch (MySqlException err)
                    {
                        MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        Environment.Exit(0);
                    }
                }
                ChecaBotoes();
                conexao.Close();
            }
            catch (MySqlException err)
            {
                MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0);
            }
        }
    }
}
