﻿using System;
using System.Windows.Forms;


namespace Alberto_Gabriel
{
    public partial class Frm_ProcurarDev : Form
    {
        public Frm_ProcurarDev()
        {
            InitializeComponent();
        }

        private void btn_Cancelar_Dev_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btn_Procurar_Dev_Click(object sender, EventArgs e)
        {
            conectar.nome_busca = txt_Procurar_Dev.Text;
            this.Close();
        }
    }
}
