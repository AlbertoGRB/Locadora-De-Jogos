﻿using System;
using System.Windows.Forms;

namespace Alberto_Gabriel
{
    public partial class Frm_ProcurarGeneros : Form
    {
        public Frm_ProcurarGeneros()
        {
            InitializeComponent();
        }

        private void btn_Cancelar_Generos_Click(object sender, EventArgs e)
        {
            conectar.descricao_busca = "";
            Close();
        }

        private void btn_Procurar_Generos_Click(object sender, EventArgs e)
        {
            conectar.descricao_busca = txt_Procurar_Generos.Text;
            this.Close();
        }
    }
}
