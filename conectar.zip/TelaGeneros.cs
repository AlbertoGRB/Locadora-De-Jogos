﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Alberto_Gabriel
{
    public partial class Frm_Generos : Form
    {
        public Frm_Generos()
        {
            InitializeComponent();
        }
       
        private void ToolStripMenuItem_Cadastrar_Click(object sender, EventArgs e)
        {
            Limpa_Campos();
            txt_Descricao.Focus();
        }

        private void ToolStripMenuItem_Alterar_Click(object sender, EventArgs e)
        {
            txt_Descricao.Focus();
            MySqlConnection conexao = conectar.fazer_conexao();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = conexao;
            try
            {
                conexao.Open();
                cmd.CommandText = "Select * from generos order by ID limit 1";
                MySqlDataReader resultado = cmd.ExecuteReader();
                if (resultado.HasRows)
                {
                    resultado.Read();
                    txt_ID.Text = resultado["ID"].ToString();
                    txt_Descricao.Text = resultado["Descricao"].ToString();
                } 
                ChecaBotoes();
                conexao.Close();
            }
            catch (MySqlException err)
            {
                MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0);
            }
        }

        private void ToolStripMenuItem_Procurar_Click(object sender, EventArgs e)
        {
            Frm_ProcurarGeneros frm_ProcurarGeneros = new Frm_ProcurarGeneros();
            frm_ProcurarGeneros.ShowDialog();
            if (conectar.descricao_busca != "")
            {
                MySqlConnection conexao = conectar.fazer_conexao();
                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = conexao;
                try
                {
                    conexao.Open();
                    cmd.CommandText = "Select * from generos where Descricao like '%" + conectar.descricao_busca + "%' order by Descricao desc limit 1";
                    MySqlDataReader resultado = cmd.ExecuteReader();
                    if (resultado.HasRows)
                    {
                        resultado.Read();
                        txt_ID.Text = resultado["ID"].ToString();
                        txt_Descricao.Text = resultado["Descricao"].ToString();
                    }
                    else
                    {
                        MessageBox.Show("Gênero " + conectar.descricao_busca + " não encontrado", "Procurar : Gêneros", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    } 
                    ChecaBotoes();
                    conexao.Close();
                }
                catch (MySqlException err)
                {
                    MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Environment.Exit(0);
                }
            }
        }

        private void ToolStripMenuItem_Excluir_Click(object sender, EventArgs e)
        {
            MySqlConnection conexao = conectar.fazer_conexao();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = conexao;
            try
            {
                conexao.Open();

                cmd.CommandText = "Select g.ID, j.Genero from jogos j, generos g where j.Genero = g.ID and g.ID = " + txt_ID.Text;

                MySqlDataReader resp = cmd.ExecuteReader();
                if (resp.HasRows)
                {
                    MessageBox.Show("Há um jogo com esse Gênero \n Gênero não pode ser excluído", "Excluir", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    resp.Close();
                    cmd.CommandText = "Delete from generos where ID = " + txt_ID.Text;
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Gênero excluído com sucesso", "Excluir", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Limpa_Campos();
                }
                ChecaBotoes();
                conexao.Close();
            }
            catch (MySqlException err)
            {
                MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0);
            }
        }

        private void btn_Salvar_Click(object sender, EventArgs e)
        {
            MySqlConnection conexao = conectar.fazer_conexao();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = conexao;
            try
            {
                conexao.Open();
                if (txt_ID.Text == "")
                {
                    cmd.CommandText = "Insert into generos (Descricao) values ('" + txt_Descricao.Text + "')";
                }
                else
                cmd.CommandText = "Update generos set Descricao = '" + txt_Descricao.Text + "' where ID = " + txt_ID.Text;
                cmd.ExecuteNonQuery();
                conexao.Close();
                MessageBox.Show("Gênero salvo com sucesso!", "Salvar : Gêneros", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Erro: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            try
            {
                conexao.Open();
                cmd.CommandText = "Select MAX(ID) from generos";
                MySqlDataReader resultado = cmd.ExecuteReader();
                if (resultado.HasRows)
                {
                    resultado.Read();
                    txt_ID.Text = resultado["MAX(ID)"].ToString();

                }

                conexao.Close();
            }
            catch (MySqlException err)
            {
                MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0);
            }
        }

        private void btn_Sair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_Proximo_Click(object sender, EventArgs e)
        {
            MySqlConnection conexao = conectar.fazer_conexao();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = conexao;
            try
            {
                conexao.Open();
                cmd.CommandText = "Select * from generos where ID > '" + txt_ID.Text + "' order by ID limit 1";
                MySqlDataReader resultado = cmd.ExecuteReader();
                if (resultado.HasRows)
                {
                    resultado.Read();
                    txt_ID.Text = resultado["ID"].ToString();
                    txt_Descricao.Text = resultado["Descricao"].ToString();
                }
                ChecaBotoes();
                conexao.Close();
            }
            catch (MySqlException err)
            {
                MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0);
            }
        }

        private void btn_Anterior_Click(object sender, EventArgs e)
        {
            MySqlConnection conexao = conectar.fazer_conexao();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = conexao;
            try
            {
                conexao.Open();
                cmd.CommandText = "Select * from generos where ID < '" + txt_ID.Text + "' order by ID desc limit 1";
                MySqlDataReader resultado = cmd.ExecuteReader();
                if (resultado.HasRows)
                {
                    resultado.Read();
                    txt_ID.Text = resultado["ID"].ToString();
                    txt_Descricao.Text = resultado["Descricao"].ToString();
                }
                ChecaBotoes();
                conexao.Close();
            }
            catch (MySqlException err)
            {
                MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0);
            }

        }

        private void Limpa_Campos()
        {
            txt_ID.Text = "";
            txt_Descricao.Text = "";
        }

      

        private void ChecaBotoes()
        {
            MySqlConnection conexao = conectar.fazer_conexao();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = conexao;
            try
            {
                conexao.Open();
                cmd.CommandText = "Select * from generos order by ID desc limit 1";
                MySqlDataReader resultado = cmd.ExecuteReader();
                if (resultado.HasRows)
                {
                    resultado.Read();
                    if (resultado["ID"].ToString() == txt_ID.Text)
                    {
                        btn_Proximo.Visible = false;
                    }
                    else
                    {
                        btn_Proximo.Visible = true;
                    }
                }
                resultado.Close();
                cmd.CommandText = "Select * from generos order by ID limit 1";
                resultado = cmd.ExecuteReader();
                if (resultado.HasRows)
                {
                    resultado.Read();
                    if (resultado["ID"].ToString() == txt_ID.Text)
                    {
                        btn_Anterior.Visible = false;
                    }
                    else
                    {
                        btn_Anterior.Visible = true;
                    }
                }
                conexao.Close();
            }
            catch (MySqlException err)
            {
                MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0);
            }
        }

        private void Frm_Generos_Load_1(object sender, EventArgs e)
        {
            txt_Descricao.Focus();
            MySqlConnection conexao = conectar.fazer_conexao(); 
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = conexao;
            try
            {
                conexao.Open();
                cmd.CommandText = "Select * from generos order by Id limit 1";
                MySqlDataReader resultado = cmd.ExecuteReader();
                if (resultado.HasRows)
                {
                    resultado.Read();
                    txt_ID.Text = resultado["ID"].ToString();
                    txt_Descricao.Text = resultado["Descricao"].ToString();
                   
                } 
                ChecaBotoes();
                conexao.Close();
            }
            catch (MySqlException err)
            {
                MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0);
            }
        }
    }
}
