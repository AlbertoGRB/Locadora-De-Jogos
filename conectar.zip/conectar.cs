﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Alberto_Gabriel
{
    internal class conectar
    {

        public static string descricao_busca;
        public static string nome_busca;
        public static MySqlConnection fazer_conexao()
        {
            return new MySqlConnection("server=localhost;database=locadora;uid=root;pwd=;port=3306;");
        }
    }
}
