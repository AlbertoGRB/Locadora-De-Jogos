﻿namespace Alberto_Gabriel
{
    partial class Frm_ProcurarJogos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_ProcurarJogos));
            this.groupBox_Procuar_Jogos = new System.Windows.Forms.GroupBox();
            this.btn_Cancelar_Jogos = new System.Windows.Forms.Button();
            this.btn_Procurar_Jogos = new System.Windows.Forms.Button();
            this.txt_Procurar_Jogos = new System.Windows.Forms.TextBox();
            this.lbl_Procurar_jogos = new System.Windows.Forms.Label();
            this.groupBox_Procuar_Jogos.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox_Procuar_Jogos
            // 
            this.groupBox_Procuar_Jogos.Controls.Add(this.btn_Cancelar_Jogos);
            this.groupBox_Procuar_Jogos.Controls.Add(this.btn_Procurar_Jogos);
            this.groupBox_Procuar_Jogos.Controls.Add(this.txt_Procurar_Jogos);
            this.groupBox_Procuar_Jogos.Controls.Add(this.lbl_Procurar_jogos);
            this.groupBox_Procuar_Jogos.Location = new System.Drawing.Point(12, 14);
            this.groupBox_Procuar_Jogos.Name = "groupBox_Procuar_Jogos";
            this.groupBox_Procuar_Jogos.Size = new System.Drawing.Size(407, 135);
            this.groupBox_Procuar_Jogos.TabIndex = 1;
            this.groupBox_Procuar_Jogos.TabStop = false;
            // 
            // btn_Cancelar_Jogos
            // 
            this.btn_Cancelar_Jogos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_Cancelar_Jogos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(100)))), ((int)(((byte)(25)))));
            this.btn_Cancelar_Jogos.Location = new System.Drawing.Point(219, 106);
            this.btn_Cancelar_Jogos.Name = "btn_Cancelar_Jogos";
            this.btn_Cancelar_Jogos.Size = new System.Drawing.Size(88, 23);
            this.btn_Cancelar_Jogos.TabIndex = 7;
            this.btn_Cancelar_Jogos.Text = "Cancelar";
            this.btn_Cancelar_Jogos.UseVisualStyleBackColor = true;
            this.btn_Cancelar_Jogos.Click += new System.EventHandler(this.btn_Cancelar_Jogos_Click);
            // 
            // btn_Procurar_Jogos
            // 
            this.btn_Procurar_Jogos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_Procurar_Jogos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(100)))), ((int)(((byte)(25)))));
            this.btn_Procurar_Jogos.Location = new System.Drawing.Point(313, 106);
            this.btn_Procurar_Jogos.Name = "btn_Procurar_Jogos";
            this.btn_Procurar_Jogos.Size = new System.Drawing.Size(88, 23);
            this.btn_Procurar_Jogos.TabIndex = 6;
            this.btn_Procurar_Jogos.Text = "Procurar";
            this.btn_Procurar_Jogos.UseVisualStyleBackColor = true;
            this.btn_Procurar_Jogos.Click += new System.EventHandler(this.btn_Procurar_Jogos_Click);
            // 
            // txt_Procurar_Jogos
            // 
            this.txt_Procurar_Jogos.Location = new System.Drawing.Point(9, 32);
            this.txt_Procurar_Jogos.Name = "txt_Procurar_Jogos";
            this.txt_Procurar_Jogos.Size = new System.Drawing.Size(392, 20);
            this.txt_Procurar_Jogos.TabIndex = 5;
            // 
            // lbl_Procurar_jogos
            // 
            this.lbl_Procurar_jogos.AutoSize = true;
            this.lbl_Procurar_jogos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Procurar_jogos.Location = new System.Drawing.Point(6, 16);
            this.lbl_Procurar_jogos.Name = "lbl_Procurar_jogos";
            this.lbl_Procurar_jogos.Size = new System.Drawing.Size(113, 16);
            this.lbl_Procurar_jogos.TabIndex = 4;
            this.lbl_Procurar_jogos.Text = "Nome do Jogo:";
            // 
            // Frm_ProcurarJogos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(431, 163);
            this.Controls.Add(this.groupBox_Procuar_Jogos);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Frm_ProcurarJogos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Locadora : Jogos : Procurar";
            this.groupBox_Procuar_Jogos.ResumeLayout(false);
            this.groupBox_Procuar_Jogos.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox_Procuar_Jogos;
        private System.Windows.Forms.Button btn_Cancelar_Jogos;
        private System.Windows.Forms.Button btn_Procurar_Jogos;
        private System.Windows.Forms.TextBox txt_Procurar_Jogos;
        private System.Windows.Forms.Label lbl_Procurar_jogos;
    }
}