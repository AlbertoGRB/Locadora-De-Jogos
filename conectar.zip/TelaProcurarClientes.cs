﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Alberto_Gabriel
{
    public partial class Frm_ProcurarClientes : Form
    {
        public Frm_ProcurarClientes()
        {
            InitializeComponent();
        }

        private void btn_Cancelar_Procurar_Cliente_Click(object sender, EventArgs e)
        {
            conectar.nome_busca = "";
            this.Close();
        }

        private void btn_Procurar_Cliente_Click(object sender, EventArgs e)
        {
            conectar.nome_busca = txt_Procurar_Cliente.Text;
            this.Close();
        }
    }
}
