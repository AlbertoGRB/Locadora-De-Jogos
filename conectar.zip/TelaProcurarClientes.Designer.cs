﻿namespace Alberto_Gabriel
{
    partial class Frm_ProcurarClientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_ProcurarClientes));
            this.groupBox_Procurar_Cliente = new System.Windows.Forms.GroupBox();
            this.btn_Cancelar_Procurar_Cliente = new System.Windows.Forms.Button();
            this.btn_Procurar_Cliente = new System.Windows.Forms.Button();
            this.txt_Procurar_Cliente = new System.Windows.Forms.TextBox();
            this.lbl_Procurar_Cliente = new System.Windows.Forms.Label();
            this.groupBox_Procurar_Cliente.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox_Procurar_Cliente
            // 
            this.groupBox_Procurar_Cliente.Controls.Add(this.btn_Cancelar_Procurar_Cliente);
            this.groupBox_Procurar_Cliente.Controls.Add(this.btn_Procurar_Cliente);
            this.groupBox_Procurar_Cliente.Controls.Add(this.txt_Procurar_Cliente);
            this.groupBox_Procurar_Cliente.Controls.Add(this.lbl_Procurar_Cliente);
            this.groupBox_Procurar_Cliente.Location = new System.Drawing.Point(16, 15);
            this.groupBox_Procurar_Cliente.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox_Procurar_Cliente.Name = "groupBox_Procurar_Cliente";
            this.groupBox_Procurar_Cliente.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox_Procurar_Cliente.Size = new System.Drawing.Size(543, 166);
            this.groupBox_Procurar_Cliente.TabIndex = 0;
            this.groupBox_Procurar_Cliente.TabStop = false;
            // 
            // btn_Cancelar_Procurar_Cliente
            // 
            this.btn_Cancelar_Procurar_Cliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_Cancelar_Procurar_Cliente.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(100)))), ((int)(((byte)(25)))));
            this.btn_Cancelar_Procurar_Cliente.Location = new System.Drawing.Point(281, 130);
            this.btn_Cancelar_Procurar_Cliente.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Cancelar_Procurar_Cliente.Name = "btn_Cancelar_Procurar_Cliente";
            this.btn_Cancelar_Procurar_Cliente.Size = new System.Drawing.Size(121, 28);
            this.btn_Cancelar_Procurar_Cliente.TabIndex = 7;
            this.btn_Cancelar_Procurar_Cliente.Text = "Cancelar";
            this.btn_Cancelar_Procurar_Cliente.UseVisualStyleBackColor = true;
            this.btn_Cancelar_Procurar_Cliente.Click += new System.EventHandler(this.btn_Cancelar_Procurar_Cliente_Click);
            // 
            // btn_Procurar_Cliente
            // 
            this.btn_Procurar_Cliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_Procurar_Cliente.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(100)))), ((int)(((byte)(25)))));
            this.btn_Procurar_Cliente.Location = new System.Drawing.Point(411, 130);
            this.btn_Procurar_Cliente.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Procurar_Cliente.Name = "btn_Procurar_Cliente";
            this.btn_Procurar_Cliente.Size = new System.Drawing.Size(124, 28);
            this.btn_Procurar_Cliente.TabIndex = 6;
            this.btn_Procurar_Cliente.Text = "Procurar";
            this.btn_Procurar_Cliente.UseVisualStyleBackColor = true;
            this.btn_Procurar_Cliente.Click += new System.EventHandler(this.btn_Procurar_Cliente_Click);
            // 
            // txt_Procurar_Cliente
            // 
            this.txt_Procurar_Cliente.Location = new System.Drawing.Point(12, 39);
            this.txt_Procurar_Cliente.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_Procurar_Cliente.Name = "txt_Procurar_Cliente";
            this.txt_Procurar_Cliente.Size = new System.Drawing.Size(521, 22);
            this.txt_Procurar_Cliente.TabIndex = 5;
            // 
            // lbl_Procurar_Cliente
            // 
            this.lbl_Procurar_Cliente.AutoSize = true;
            this.lbl_Procurar_Cliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Procurar_Cliente.Location = new System.Drawing.Point(8, 20);
            this.lbl_Procurar_Cliente.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Procurar_Cliente.Name = "lbl_Procurar_Cliente";
            this.lbl_Procurar_Cliente.Size = new System.Drawing.Size(154, 20);
            this.lbl_Procurar_Cliente.TabIndex = 4;
            this.lbl_Procurar_Cliente.Text = "Nome do Cliente:";
            // 
            // Frm_ProcurarClientes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(575, 201);
            this.Controls.Add(this.groupBox_Procurar_Cliente);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Frm_ProcurarClientes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Locadora : Clientes : Procurar";
            this.groupBox_Procurar_Cliente.ResumeLayout(false);
            this.groupBox_Procurar_Cliente.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox_Procurar_Cliente;
        private System.Windows.Forms.Button btn_Cancelar_Procurar_Cliente;
        private System.Windows.Forms.Button btn_Procurar_Cliente;
        private System.Windows.Forms.TextBox txt_Procurar_Cliente;
        private System.Windows.Forms.Label lbl_Procurar_Cliente;
    }
}