﻿namespace Alberto_Gabriel
{
    partial class Frm_Clientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_Clientes));
            this.btn_Cancelar = new System.Windows.Forms.Button();
            this.txt_Observacao = new System.Windows.Forms.TextBox();
            this.groupBox_Clientes = new System.Windows.Forms.GroupBox();
            this.btn_Anterior = new System.Windows.Forms.Button();
            this.btn_Proximo = new System.Windows.Forms.Button();
            this.maskedTextBox_Data_de_Nascimento = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox_Celular = new System.Windows.Forms.MaskedTextBox();
            this.txt_Email = new System.Windows.Forms.TextBox();
            this.txt_Documento = new System.Windows.Forms.TextBox();
            this.txt_Endereco = new System.Windows.Forms.TextBox();
            this.txt_Bairro = new System.Windows.Forms.TextBox();
            this.txt_CEP = new System.Windows.Forms.TextBox();
            this.txt_Cidade = new System.Windows.Forms.TextBox();
            this.txt_Estado = new System.Windows.Forms.TextBox();
            this.lbl_Endereco = new System.Windows.Forms.Label();
            this.lbl_Estado = new System.Windows.Forms.Label();
            this.lbl_Email = new System.Windows.Forms.Label();
            this.lbl_Celular = new System.Windows.Forms.Label();
            this.lbl_CEP = new System.Windows.Forms.Label();
            this.lbl_Cidade = new System.Windows.Forms.Label();
            this.lbl_Documento = new System.Windows.Forms.Label();
            this.lbl_Bairro = new System.Windows.Forms.Label();
            this.lbl_Data_de_Nascimento = new System.Windows.Forms.Label();
            this.txt_Nome = new System.Windows.Forms.TextBox();
            this.lbl_Nome = new System.Windows.Forms.Label();
            this.txt_ID = new System.Windows.Forms.TextBox();
            this.lbl_ID = new System.Windows.Forms.Label();
            this.lbl_Observacao = new System.Windows.Forms.Label();
            this.btn_Salvar = new System.Windows.Forms.Button();
            this.ToolStripMenuItem_Cadastrar = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_Alterar = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_Procurar = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_Excluir = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip_Clientes = new System.Windows.Forms.MenuStrip();
            this.groupBox_Clientes.SuspendLayout();
            this.menuStrip_Clientes.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Cancelar
            // 
            this.btn_Cancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_Cancelar.ForeColor = System.Drawing.Color.DarkCyan;
            this.btn_Cancelar.Location = new System.Drawing.Point(859, 497);
            this.btn_Cancelar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Cancelar.Name = "btn_Cancelar";
            this.btn_Cancelar.Size = new System.Drawing.Size(120, 36);
            this.btn_Cancelar.TabIndex = 0;
            this.btn_Cancelar.Text = "Cancelar";
            this.btn_Cancelar.UseVisualStyleBackColor = true;
            this.btn_Cancelar.Click += new System.EventHandler(this.btn_Sair_Click);
            // 
            // txt_Observacao
            // 
            this.txt_Observacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Observacao.Location = new System.Drawing.Point(25, 432);
            this.txt_Observacao.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Observacao.Multiline = true;
            this.txt_Observacao.Name = "txt_Observacao";
            this.txt_Observacao.Size = new System.Drawing.Size(783, 100);
            this.txt_Observacao.TabIndex = 26;
            // 
            // groupBox_Clientes
            // 
            this.groupBox_Clientes.Controls.Add(this.btn_Anterior);
            this.groupBox_Clientes.Controls.Add(this.btn_Proximo);
            this.groupBox_Clientes.Controls.Add(this.maskedTextBox_Data_de_Nascimento);
            this.groupBox_Clientes.Controls.Add(this.maskedTextBox_Celular);
            this.groupBox_Clientes.Controls.Add(this.txt_Email);
            this.groupBox_Clientes.Controls.Add(this.txt_Documento);
            this.groupBox_Clientes.Controls.Add(this.txt_Endereco);
            this.groupBox_Clientes.Controls.Add(this.txt_Bairro);
            this.groupBox_Clientes.Controls.Add(this.txt_CEP);
            this.groupBox_Clientes.Controls.Add(this.txt_Cidade);
            this.groupBox_Clientes.Controls.Add(this.txt_Estado);
            this.groupBox_Clientes.Controls.Add(this.lbl_Endereco);
            this.groupBox_Clientes.Controls.Add(this.lbl_Estado);
            this.groupBox_Clientes.Controls.Add(this.lbl_Email);
            this.groupBox_Clientes.Controls.Add(this.lbl_Celular);
            this.groupBox_Clientes.Controls.Add(this.lbl_CEP);
            this.groupBox_Clientes.Controls.Add(this.lbl_Cidade);
            this.groupBox_Clientes.Controls.Add(this.lbl_Documento);
            this.groupBox_Clientes.Controls.Add(this.lbl_Bairro);
            this.groupBox_Clientes.Controls.Add(this.lbl_Data_de_Nascimento);
            this.groupBox_Clientes.Controls.Add(this.txt_Nome);
            this.groupBox_Clientes.Controls.Add(this.lbl_Nome);
            this.groupBox_Clientes.Controls.Add(this.txt_ID);
            this.groupBox_Clientes.Controls.Add(this.lbl_ID);
            this.groupBox_Clientes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox_Clientes.ForeColor = System.Drawing.Color.DarkCyan;
            this.groupBox_Clientes.Location = new System.Drawing.Point(16, 69);
            this.groupBox_Clientes.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox_Clientes.Name = "groupBox_Clientes";
            this.groupBox_Clientes.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox_Clientes.Size = new System.Drawing.Size(963, 331);
            this.groupBox_Clientes.TabIndex = 31;
            this.groupBox_Clientes.TabStop = false;
            this.groupBox_Clientes.Text = "DADOS PESSOAIS";
            // 
            // btn_Anterior
            // 
            this.btn_Anterior.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_Anterior.ForeColor = System.Drawing.Color.DarkCyan;
            this.btn_Anterior.Location = new System.Drawing.Point(835, 297);
            this.btn_Anterior.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Anterior.Name = "btn_Anterior";
            this.btn_Anterior.Size = new System.Drawing.Size(120, 27);
            this.btn_Anterior.TabIndex = 57;
            this.btn_Anterior.Text = "Anterior";
            this.btn_Anterior.UseVisualStyleBackColor = true;
            this.btn_Anterior.Click += new System.EventHandler(this.btn_Anterior_Click);
            // 
            // btn_Proximo
            // 
            this.btn_Proximo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_Proximo.ForeColor = System.Drawing.Color.DarkCyan;
            this.btn_Proximo.Location = new System.Drawing.Point(835, 262);
            this.btn_Proximo.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Proximo.Name = "btn_Proximo";
            this.btn_Proximo.Size = new System.Drawing.Size(120, 27);
            this.btn_Proximo.TabIndex = 56;
            this.btn_Proximo.Text = "Próximo";
            this.btn_Proximo.UseVisualStyleBackColor = true;
            this.btn_Proximo.Click += new System.EventHandler(this.btn_Proximo_Click);
            // 
            // maskedTextBox_Data_de_Nascimento
            // 
            this.maskedTextBox_Data_de_Nascimento.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBox_Data_de_Nascimento.Location = new System.Drawing.Point(381, 113);
            this.maskedTextBox_Data_de_Nascimento.Margin = new System.Windows.Forms.Padding(4);
            this.maskedTextBox_Data_de_Nascimento.Mask = "00/00/0000";
            this.maskedTextBox_Data_de_Nascimento.Name = "maskedTextBox_Data_de_Nascimento";
            this.maskedTextBox_Data_de_Nascimento.Size = new System.Drawing.Size(113, 26);
            this.maskedTextBox_Data_de_Nascimento.TabIndex = 55;
            this.maskedTextBox_Data_de_Nascimento.ValidatingType = typeof(System.DateTime);
            // 
            // maskedTextBox_Celular
            // 
            this.maskedTextBox_Celular.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBox_Celular.Location = new System.Drawing.Point(8, 279);
            this.maskedTextBox_Celular.Margin = new System.Windows.Forms.Padding(4);
            this.maskedTextBox_Celular.Mask = "(99) 00000-0000";
            this.maskedTextBox_Celular.Name = "maskedTextBox_Celular";
            this.maskedTextBox_Celular.Size = new System.Drawing.Size(188, 26);
            this.maskedTextBox_Celular.TabIndex = 53;
            // 
            // txt_Email
            // 
            this.txt_Email.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Email.ForeColor = System.Drawing.Color.Black;
            this.txt_Email.Location = new System.Drawing.Point(205, 279);
            this.txt_Email.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Email.Name = "txt_Email";
            this.txt_Email.Size = new System.Drawing.Size(335, 26);
            this.txt_Email.TabIndex = 49;
            // 
            // txt_Documento
            // 
            this.txt_Documento.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Documento.ForeColor = System.Drawing.Color.Black;
            this.txt_Documento.Location = new System.Drawing.Point(148, 113);
            this.txt_Documento.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Documento.Name = "txt_Documento";
            this.txt_Documento.Size = new System.Drawing.Size(224, 26);
            this.txt_Documento.TabIndex = 47;
            // 
            // txt_Endereco
            // 
            this.txt_Endereco.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Endereco.ForeColor = System.Drawing.Color.Black;
            this.txt_Endereco.Location = new System.Drawing.Point(8, 174);
            this.txt_Endereco.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Endereco.Name = "txt_Endereco";
            this.txt_Endereco.Size = new System.Drawing.Size(412, 26);
            this.txt_Endereco.TabIndex = 46;
            // 
            // txt_Bairro
            // 
            this.txt_Bairro.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Bairro.ForeColor = System.Drawing.Color.Black;
            this.txt_Bairro.Location = new System.Drawing.Point(429, 174);
            this.txt_Bairro.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Bairro.Name = "txt_Bairro";
            this.txt_Bairro.Size = new System.Drawing.Size(363, 26);
            this.txt_Bairro.TabIndex = 45;
            // 
            // txt_CEP
            // 
            this.txt_CEP.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_CEP.ForeColor = System.Drawing.Color.Black;
            this.txt_CEP.Location = new System.Drawing.Point(592, 226);
            this.txt_CEP.Margin = new System.Windows.Forms.Padding(4);
            this.txt_CEP.Name = "txt_CEP";
            this.txt_CEP.Size = new System.Drawing.Size(200, 26);
            this.txt_CEP.TabIndex = 44;
            // 
            // txt_Cidade
            // 
            this.txt_Cidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Cidade.ForeColor = System.Drawing.Color.Black;
            this.txt_Cidade.Location = new System.Drawing.Point(8, 226);
            this.txt_Cidade.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Cidade.Name = "txt_Cidade";
            this.txt_Cidade.Size = new System.Drawing.Size(327, 26);
            this.txt_Cidade.TabIndex = 43;
            // 
            // txt_Estado
            // 
            this.txt_Estado.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Estado.ForeColor = System.Drawing.Color.Black;
            this.txt_Estado.Location = new System.Drawing.Point(344, 226);
            this.txt_Estado.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Estado.Name = "txt_Estado";
            this.txt_Estado.Size = new System.Drawing.Size(239, 26);
            this.txt_Estado.TabIndex = 42;
            // 
            // lbl_Endereco
            // 
            this.lbl_Endereco.AutoSize = true;
            this.lbl_Endereco.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Endereco.ForeColor = System.Drawing.Color.Black;
            this.lbl_Endereco.Location = new System.Drawing.Point(7, 150);
            this.lbl_Endereco.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Endereco.Name = "lbl_Endereco";
            this.lbl_Endereco.Size = new System.Drawing.Size(94, 20);
            this.lbl_Endereco.TabIndex = 41;
            this.lbl_Endereco.Text = "Endereço:";
            // 
            // lbl_Estado
            // 
            this.lbl_Estado.AutoSize = true;
            this.lbl_Estado.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Estado.ForeColor = System.Drawing.Color.Black;
            this.lbl_Estado.Location = new System.Drawing.Point(332, 203);
            this.lbl_Estado.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Estado.Name = "lbl_Estado";
            this.lbl_Estado.Size = new System.Drawing.Size(73, 20);
            this.lbl_Estado.TabIndex = 40;
            this.lbl_Estado.Text = "Estado:";
            // 
            // lbl_Email
            // 
            this.lbl_Email.AutoSize = true;
            this.lbl_Email.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Email.ForeColor = System.Drawing.Color.Black;
            this.lbl_Email.Location = new System.Drawing.Point(201, 256);
            this.lbl_Email.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Email.Name = "lbl_Email";
            this.lbl_Email.Size = new System.Drawing.Size(69, 20);
            this.lbl_Email.TabIndex = 39;
            this.lbl_Email.Text = "E-mail:";
            // 
            // lbl_Celular
            // 
            this.lbl_Celular.AutoSize = true;
            this.lbl_Celular.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Celular.ForeColor = System.Drawing.Color.Black;
            this.lbl_Celular.Location = new System.Drawing.Point(8, 256);
            this.lbl_Celular.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Celular.Name = "lbl_Celular";
            this.lbl_Celular.Size = new System.Drawing.Size(75, 20);
            this.lbl_Celular.TabIndex = 36;
            this.lbl_Celular.Text = "Celular:";
            // 
            // lbl_CEP
            // 
            this.lbl_CEP.AutoSize = true;
            this.lbl_CEP.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_CEP.ForeColor = System.Drawing.Color.Black;
            this.lbl_CEP.Location = new System.Drawing.Point(588, 203);
            this.lbl_CEP.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_CEP.Name = "lbl_CEP";
            this.lbl_CEP.Size = new System.Drawing.Size(52, 20);
            this.lbl_CEP.TabIndex = 35;
            this.lbl_CEP.Text = "CEP:";
            // 
            // lbl_Cidade
            // 
            this.lbl_Cidade.AutoSize = true;
            this.lbl_Cidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Cidade.ForeColor = System.Drawing.Color.Black;
            this.lbl_Cidade.Location = new System.Drawing.Point(4, 203);
            this.lbl_Cidade.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Cidade.Name = "lbl_Cidade";
            this.lbl_Cidade.Size = new System.Drawing.Size(73, 20);
            this.lbl_Cidade.TabIndex = 34;
            this.lbl_Cidade.Text = "Cidade:";
            // 
            // lbl_Documento
            // 
            this.lbl_Documento.AutoSize = true;
            this.lbl_Documento.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Documento.ForeColor = System.Drawing.Color.Black;
            this.lbl_Documento.Location = new System.Drawing.Point(141, 90);
            this.lbl_Documento.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Documento.Name = "lbl_Documento";
            this.lbl_Documento.Size = new System.Drawing.Size(110, 20);
            this.lbl_Documento.TabIndex = 33;
            this.lbl_Documento.Text = "Documento:";
            // 
            // lbl_Bairro
            // 
            this.lbl_Bairro.AutoSize = true;
            this.lbl_Bairro.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Bairro.ForeColor = System.Drawing.Color.Black;
            this.lbl_Bairro.Location = new System.Drawing.Point(425, 150);
            this.lbl_Bairro.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Bairro.Name = "lbl_Bairro";
            this.lbl_Bairro.Size = new System.Drawing.Size(67, 20);
            this.lbl_Bairro.TabIndex = 32;
            this.lbl_Bairro.Text = "Bairro:";
            // 
            // lbl_Data_de_Nascimento
            // 
            this.lbl_Data_de_Nascimento.AutoSize = true;
            this.lbl_Data_de_Nascimento.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Data_de_Nascimento.ForeColor = System.Drawing.Color.Black;
            this.lbl_Data_de_Nascimento.Location = new System.Drawing.Point(377, 90);
            this.lbl_Data_de_Nascimento.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Data_de_Nascimento.Name = "lbl_Data_de_Nascimento";
            this.lbl_Data_de_Nascimento.Size = new System.Drawing.Size(186, 20);
            this.lbl_Data_de_Nascimento.TabIndex = 30;
            this.lbl_Data_de_Nascimento.Text = "Data de Nascimento:";
            // 
            // txt_Nome
            // 
            this.txt_Nome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Nome.ForeColor = System.Drawing.Color.Black;
            this.txt_Nome.Location = new System.Drawing.Point(9, 57);
            this.txt_Nome.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Nome.Multiline = true;
            this.txt_Nome.Name = "txt_Nome";
            this.txt_Nome.Size = new System.Drawing.Size(783, 24);
            this.txt_Nome.TabIndex = 29;
            // 
            // lbl_Nome
            // 
            this.lbl_Nome.AutoSize = true;
            this.lbl_Nome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Nome.ForeColor = System.Drawing.Color.Black;
            this.lbl_Nome.Location = new System.Drawing.Point(4, 33);
            this.lbl_Nome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Nome.Name = "lbl_Nome";
            this.lbl_Nome.Size = new System.Drawing.Size(148, 20);
            this.lbl_Nome.TabIndex = 28;
            this.lbl_Nome.Text = "Nome Completo:";
            // 
            // txt_ID
            // 
            this.txt_ID.Enabled = false;
            this.txt_ID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ID.ForeColor = System.Drawing.Color.Black;
            this.txt_ID.Location = new System.Drawing.Point(9, 113);
            this.txt_ID.Margin = new System.Windows.Forms.Padding(4);
            this.txt_ID.Name = "txt_ID";
            this.txt_ID.Size = new System.Drawing.Size(129, 26);
            this.txt_ID.TabIndex = 27;
            // 
            // lbl_ID
            // 
            this.lbl_ID.AutoSize = true;
            this.lbl_ID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_ID.ForeColor = System.Drawing.Color.Black;
            this.lbl_ID.Location = new System.Drawing.Point(4, 90);
            this.lbl_ID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_ID.Name = "lbl_ID";
            this.lbl_ID.Size = new System.Drawing.Size(34, 20);
            this.lbl_ID.TabIndex = 26;
            this.lbl_ID.Text = "ID:";
            // 
            // lbl_Observacao
            // 
            this.lbl_Observacao.AutoSize = true;
            this.lbl_Observacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Observacao.ForeColor = System.Drawing.Color.Black;
            this.lbl_Observacao.Location = new System.Drawing.Point(20, 404);
            this.lbl_Observacao.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Observacao.Name = "lbl_Observacao";
            this.lbl_Observacao.Size = new System.Drawing.Size(125, 20);
            this.lbl_Observacao.TabIndex = 38;
            this.lbl_Observacao.Text = "Observações:";
            // 
            // btn_Salvar
            // 
            this.btn_Salvar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_Salvar.ForeColor = System.Drawing.Color.DarkCyan;
            this.btn_Salvar.Location = new System.Drawing.Point(859, 454);
            this.btn_Salvar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Salvar.Name = "btn_Salvar";
            this.btn_Salvar.Size = new System.Drawing.Size(120, 36);
            this.btn_Salvar.TabIndex = 40;
            this.btn_Salvar.Text = "Salvar";
            this.btn_Salvar.UseVisualStyleBackColor = true;
            this.btn_Salvar.Click += new System.EventHandler(this.btn_Salvar_Click);
            // 
            // ToolStripMenuItem_Cadastrar
            // 
            this.ToolStripMenuItem_Cadastrar.AutoSize = false;
            this.ToolStripMenuItem_Cadastrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold);
            this.ToolStripMenuItem_Cadastrar.Name = "ToolStripMenuItem_Cadastrar";
            this.ToolStripMenuItem_Cadastrar.Size = new System.Drawing.Size(87, 28);
            this.ToolStripMenuItem_Cadastrar.Text = "Cadastrar";
            this.ToolStripMenuItem_Cadastrar.Click += new System.EventHandler(this.ToolStripMenuItem_Cadastrar_Click);
            // 
            // ToolStripMenuItem_Alterar
            // 
            this.ToolStripMenuItem_Alterar.AutoSize = false;
            this.ToolStripMenuItem_Alterar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold);
            this.ToolStripMenuItem_Alterar.Name = "ToolStripMenuItem_Alterar";
            this.ToolStripMenuItem_Alterar.Size = new System.Drawing.Size(65, 28);
            this.ToolStripMenuItem_Alterar.Text = "Alterar";
            this.ToolStripMenuItem_Alterar.Click += new System.EventHandler(this.ToolStripMenuItem_Alterar_Click);
            // 
            // ToolStripMenuItem_Procurar
            // 
            this.ToolStripMenuItem_Procurar.AutoSize = false;
            this.ToolStripMenuItem_Procurar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold);
            this.ToolStripMenuItem_Procurar.Name = "ToolStripMenuItem_Procurar";
            this.ToolStripMenuItem_Procurar.Size = new System.Drawing.Size(152, 28);
            this.ToolStripMenuItem_Procurar.Text = "Procurar Cliente ";
            this.ToolStripMenuItem_Procurar.Click += new System.EventHandler(this.ToolStripMenuItem_Procurar_Click);
            // 
            // ToolStripMenuItem_Excluir
            // 
            this.ToolStripMenuItem_Excluir.AutoSize = false;
            this.ToolStripMenuItem_Excluir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold);
            this.ToolStripMenuItem_Excluir.ForeColor = System.Drawing.Color.Black;
            this.ToolStripMenuItem_Excluir.Name = "ToolStripMenuItem_Excluir";
            this.ToolStripMenuItem_Excluir.Size = new System.Drawing.Size(65, 28);
            this.ToolStripMenuItem_Excluir.Text = "Excluir";
            this.ToolStripMenuItem_Excluir.Click += new System.EventHandler(this.ToolStripMenuItem_Excluir_Click);
            // 
            // menuStrip_Clientes
            // 
            this.menuStrip_Clientes.AutoSize = false;
            this.menuStrip_Clientes.BackColor = System.Drawing.Color.DarkCyan;
            this.menuStrip_Clientes.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip_Clientes.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip_Clientes.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem_Cadastrar,
            this.ToolStripMenuItem_Alterar,
            this.ToolStripMenuItem_Procurar,
            this.ToolStripMenuItem_Excluir});
            this.menuStrip_Clientes.Location = new System.Drawing.Point(0, 0);
            this.menuStrip_Clientes.Name = "menuStrip_Clientes";
            this.menuStrip_Clientes.Size = new System.Drawing.Size(995, 39);
            this.menuStrip_Clientes.TabIndex = 42;
            // 
            // Frm_Clientes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(995, 548);
            this.Controls.Add(this.menuStrip_Clientes);
            this.Controls.Add(this.btn_Salvar);
            this.Controls.Add(this.groupBox_Clientes);
            this.Controls.Add(this.txt_Observacao);
            this.Controls.Add(this.btn_Cancelar);
            this.Controls.Add(this.lbl_Observacao);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip_Clientes;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Frm_Clientes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Locadora : Clientes";
            this.Load += new System.EventHandler(this.Frm_Clientes_Load);
            this.groupBox_Clientes.ResumeLayout(false);
            this.groupBox_Clientes.PerformLayout();
            this.menuStrip_Clientes.ResumeLayout(false);
            this.menuStrip_Clientes.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Cancelar;
        private System.Windows.Forms.TextBox txt_Observacao;
        private System.Windows.Forms.GroupBox groupBox_Clientes;
        private System.Windows.Forms.TextBox txt_Email;
        private System.Windows.Forms.TextBox txt_Documento;
        private System.Windows.Forms.TextBox txt_Endereco;
        private System.Windows.Forms.TextBox txt_Bairro;
        private System.Windows.Forms.TextBox txt_CEP;
        private System.Windows.Forms.TextBox txt_Cidade;
        private System.Windows.Forms.Label lbl_Nome;
        private System.Windows.Forms.TextBox txt_Estado;
        private System.Windows.Forms.Label lbl_Endereco;
        private System.Windows.Forms.Label lbl_Estado;
        private System.Windows.Forms.Label lbl_Email;
        private System.Windows.Forms.Label lbl_Celular;
        private System.Windows.Forms.Label lbl_CEP;
        private System.Windows.Forms.Label lbl_Cidade;
        private System.Windows.Forms.Label lbl_Documento;
        private System.Windows.Forms.Label lbl_Bairro;
        private System.Windows.Forms.Label lbl_Data_de_Nascimento;
        private System.Windows.Forms.TextBox txt_Nome;
        private System.Windows.Forms.TextBox txt_ID;
        private System.Windows.Forms.Label lbl_ID;
        private System.Windows.Forms.Label lbl_Observacao;
        private System.Windows.Forms.Button btn_Salvar;
        private System.Windows.Forms.MaskedTextBox maskedTextBox_Celular;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_Cadastrar;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_Alterar;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_Procurar;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_Excluir;
        private System.Windows.Forms.MenuStrip menuStrip_Clientes;
        private System.Windows.Forms.MaskedTextBox maskedTextBox_Data_de_Nascimento;
        private System.Windows.Forms.Button btn_Anterior;
        private System.Windows.Forms.Button btn_Proximo;
    }
}