﻿namespace Alberto_Gabriel
{
    partial class Frm_OperacoesEmp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_OperacoesEmp));
            this.lbl_ID_Operacoes = new System.Windows.Forms.Label();
            this.txt_ID_Operacoes = new System.Windows.Forms.TextBox();
            this.ID_Clientes = new System.Windows.Forms.Label();
            this.lbl_Valor_Total = new System.Windows.Forms.Label();
            this.lD_Jogos = new System.Windows.Forms.Label();
            this.lbl_Data_de_Locacao = new System.Windows.Forms.Label();
            this.groupBoxEmpréstimos = new System.Windows.Forms.GroupBox();
            this.Escolher_Cliente = new System.Windows.Forms.ListBox();
            this.dataGridView_Jogos = new System.Windows.Forms.DataGridView();
            this.select = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.btn_Anterior = new System.Windows.Forms.Button();
            this.btn_Proximo = new System.Windows.Forms.Button();
            this.maskedTextBox_Data_de_Locacao = new System.Windows.Forms.MaskedTextBox();
            this.txt_Valor_Total = new System.Windows.Forms.TextBox();
            this.btn_Cancelar = new System.Windows.Forms.Button();
            this.btn_Salvar = new System.Windows.Forms.Button();
            this.menuStrip_Ope_Emp = new System.Windows.Forms.MenuStrip();
            this.ToolStripMenuItem_Emprestar_Jogos = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripMenuItem_Procurar_Empréstimo = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_Imp_Emprestimo = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBoxEmpréstimos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Jogos)).BeginInit();
            this.menuStrip_Ope_Emp.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_ID_Operacoes
            // 
            this.lbl_ID_Operacoes.AutoSize = true;
            this.lbl_ID_Operacoes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_ID_Operacoes.ForeColor = System.Drawing.Color.Black;
            this.lbl_ID_Operacoes.Location = new System.Drawing.Point(4, 37);
            this.lbl_ID_Operacoes.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_ID_Operacoes.Name = "lbl_ID_Operacoes";
            this.lbl_ID_Operacoes.Size = new System.Drawing.Size(131, 20);
            this.lbl_ID_Operacoes.TabIndex = 37;
            this.lbl_ID_Operacoes.Text = "ID Operações:";
            // 
            // txt_ID_Operacoes
            // 
            this.txt_ID_Operacoes.Enabled = false;
            this.txt_ID_Operacoes.Location = new System.Drawing.Point(8, 60);
            this.txt_ID_Operacoes.Margin = new System.Windows.Forms.Padding(4);
            this.txt_ID_Operacoes.Name = "txt_ID_Operacoes";
            this.txt_ID_Operacoes.Size = new System.Drawing.Size(153, 24);
            this.txt_ID_Operacoes.TabIndex = 40;
            // 
            // ID_Clientes
            // 
            this.ID_Clientes.AutoSize = true;
            this.ID_Clientes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.ID_Clientes.ForeColor = System.Drawing.Color.Black;
            this.ID_Clientes.Location = new System.Drawing.Point(167, 37);
            this.ID_Clientes.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ID_Clientes.Name = "ID_Clientes";
            this.ID_Clientes.Size = new System.Drawing.Size(154, 20);
            this.ID_Clientes.TabIndex = 39;
            this.ID_Clientes.Text = "Nome do Cliente:";
            // 
            // lbl_Valor_Total
            // 
            this.lbl_Valor_Total.AutoSize = true;
            this.lbl_Valor_Total.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Valor_Total.ForeColor = System.Drawing.Color.Black;
            this.lbl_Valor_Total.Location = new System.Drawing.Point(655, 37);
            this.lbl_Valor_Total.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Valor_Total.Name = "lbl_Valor_Total";
            this.lbl_Valor_Total.Size = new System.Drawing.Size(210, 20);
            this.lbl_Valor_Total.TabIndex = 41;
            this.lbl_Valor_Total.Text = "Valor Total da Locação:";
            // 
            // lD_Jogos
            // 
            this.lD_Jogos.AutoSize = true;
            this.lD_Jogos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lD_Jogos.ForeColor = System.Drawing.Color.Black;
            this.lD_Jogos.Location = new System.Drawing.Point(4, 123);
            this.lD_Jogos.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lD_Jogos.Name = "lD_Jogos";
            this.lD_Jogos.Size = new System.Drawing.Size(59, 20);
            this.lD_Jogos.TabIndex = 43;
            this.lD_Jogos.Text = "Jogos";
            // 
            // lbl_Data_de_Locacao
            // 
            this.lbl_Data_de_Locacao.AutoSize = true;
            this.lbl_Data_de_Locacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Data_de_Locacao.ForeColor = System.Drawing.Color.Black;
            this.lbl_Data_de_Locacao.Location = new System.Drawing.Point(473, 37);
            this.lbl_Data_de_Locacao.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Data_de_Locacao.Name = "lbl_Data_de_Locacao";
            this.lbl_Data_de_Locacao.Size = new System.Drawing.Size(158, 20);
            this.lbl_Data_de_Locacao.TabIndex = 45;
            this.lbl_Data_de_Locacao.Text = "Data de Locação:";
            // 
            // groupBoxEmpréstimos
            // 
            this.groupBoxEmpréstimos.Controls.Add(this.Escolher_Cliente);
            this.groupBoxEmpréstimos.Controls.Add(this.dataGridView_Jogos);
            this.groupBoxEmpréstimos.Controls.Add(this.btn_Anterior);
            this.groupBoxEmpréstimos.Controls.Add(this.btn_Proximo);
            this.groupBoxEmpréstimos.Controls.Add(this.maskedTextBox_Data_de_Locacao);
            this.groupBoxEmpréstimos.Controls.Add(this.ID_Clientes);
            this.groupBoxEmpréstimos.Controls.Add(this.lbl_ID_Operacoes);
            this.groupBoxEmpréstimos.Controls.Add(this.txt_Valor_Total);
            this.groupBoxEmpréstimos.Controls.Add(this.txt_ID_Operacoes);
            this.groupBoxEmpréstimos.Controls.Add(this.lbl_Valor_Total);
            this.groupBoxEmpréstimos.Controls.Add(this.lbl_Data_de_Locacao);
            this.groupBoxEmpréstimos.Controls.Add(this.lD_Jogos);
            this.groupBoxEmpréstimos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.groupBoxEmpréstimos.ForeColor = System.Drawing.Color.DarkCyan;
            this.groupBoxEmpréstimos.Location = new System.Drawing.Point(16, 69);
            this.groupBoxEmpréstimos.Margin = new System.Windows.Forms.Padding(4);
            this.groupBoxEmpréstimos.Name = "groupBoxEmpréstimos";
            this.groupBoxEmpréstimos.Padding = new System.Windows.Forms.Padding(4);
            this.groupBoxEmpréstimos.Size = new System.Drawing.Size(963, 378);
            this.groupBoxEmpréstimos.TabIndex = 50;
            this.groupBoxEmpréstimos.TabStop = false;
            this.groupBoxEmpréstimos.Text = "DADOS DOS EMPRÉSTIMOS";
            // 
            // Escolher_Cliente
            // 
            this.Escolher_Cliente.FormattingEnabled = true;
            this.Escolher_Cliente.ItemHeight = 18;
            this.Escolher_Cliente.Location = new System.Drawing.Point(171, 60);
            this.Escolher_Cliente.Margin = new System.Windows.Forms.Padding(4);
            this.Escolher_Cliente.Name = "Escolher_Cliente";
            this.Escolher_Cliente.Size = new System.Drawing.Size(281, 76);
            this.Escolher_Cliente.TabIndex = 67;
            // 
            // dataGridView_Jogos
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dataGridView_Jogos.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_Jogos.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView_Jogos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_Jogos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Jogos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.select});
            this.dataGridView_Jogos.Location = new System.Drawing.Point(8, 146);
            this.dataGridView_Jogos.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView_Jogos.Name = "dataGridView_Jogos";
            this.dataGridView_Jogos.RowHeadersVisible = false;
            this.dataGridView_Jogos.RowHeadersWidth = 45;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dataGridView_Jogos.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView_Jogos.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dataGridView_Jogos.Size = new System.Drawing.Size(445, 208);
            this.dataGridView_Jogos.TabIndex = 65;
            // 
            // select
            // 
            this.select.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.select.HeaderText = "";
            this.select.MinimumWidth = 6;
            this.select.Name = "select";
            this.select.Width = 24;
            // 
            // btn_Anterior
            // 
            this.btn_Anterior.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_Anterior.ForeColor = System.Drawing.Color.DarkCyan;
            this.btn_Anterior.Location = new System.Drawing.Point(461, 327);
            this.btn_Anterior.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Anterior.Name = "btn_Anterior";
            this.btn_Anterior.Size = new System.Drawing.Size(120, 27);
            this.btn_Anterior.TabIndex = 65;
            this.btn_Anterior.Text = "Anterior";
            this.btn_Anterior.UseVisualStyleBackColor = true;
            this.btn_Anterior.Click += new System.EventHandler(this.btn_Anterior_Click);
            // 
            // btn_Proximo
            // 
            this.btn_Proximo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_Proximo.ForeColor = System.Drawing.Color.DarkCyan;
            this.btn_Proximo.Location = new System.Drawing.Point(461, 293);
            this.btn_Proximo.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Proximo.Name = "btn_Proximo";
            this.btn_Proximo.Size = new System.Drawing.Size(120, 27);
            this.btn_Proximo.TabIndex = 64;
            this.btn_Proximo.Text = "Próximo";
            this.btn_Proximo.UseVisualStyleBackColor = true;
            this.btn_Proximo.Click += new System.EventHandler(this.btn_Proximo_Click);
            // 
            // maskedTextBox_Data_de_Locacao
            // 
            this.maskedTextBox_Data_de_Locacao.Location = new System.Drawing.Point(477, 60);
            this.maskedTextBox_Data_de_Locacao.Margin = new System.Windows.Forms.Padding(4);
            this.maskedTextBox_Data_de_Locacao.Mask = "00/00/0000";
            this.maskedTextBox_Data_de_Locacao.Name = "maskedTextBox_Data_de_Locacao";
            this.maskedTextBox_Data_de_Locacao.Size = new System.Drawing.Size(125, 24);
            this.maskedTextBox_Data_de_Locacao.TabIndex = 50;
            this.maskedTextBox_Data_de_Locacao.ValidatingType = typeof(System.DateTime);
            // 
            // txt_Valor_Total
            // 
            this.txt_Valor_Total.Enabled = false;
            this.txt_Valor_Total.Location = new System.Drawing.Point(659, 60);
            this.txt_Valor_Total.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Valor_Total.Name = "txt_Valor_Total";
            this.txt_Valor_Total.Size = new System.Drawing.Size(252, 24);
            this.txt_Valor_Total.TabIndex = 38;
            // 
            // btn_Cancelar
            // 
            this.btn_Cancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_Cancelar.ForeColor = System.Drawing.Color.DarkCyan;
            this.btn_Cancelar.Location = new System.Drawing.Point(859, 497);
            this.btn_Cancelar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Cancelar.Name = "btn_Cancelar";
            this.btn_Cancelar.Size = new System.Drawing.Size(120, 36);
            this.btn_Cancelar.TabIndex = 1;
            this.btn_Cancelar.Text = "Cancelar";
            this.btn_Cancelar.UseVisualStyleBackColor = true;
            this.btn_Cancelar.Click += new System.EventHandler(this.btn_Cancelar_Click);
            // 
            // btn_Salvar
            // 
            this.btn_Salvar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_Salvar.ForeColor = System.Drawing.Color.DarkCyan;
            this.btn_Salvar.Location = new System.Drawing.Point(859, 454);
            this.btn_Salvar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Salvar.Name = "btn_Salvar";
            this.btn_Salvar.Size = new System.Drawing.Size(120, 36);
            this.btn_Salvar.TabIndex = 51;
            this.btn_Salvar.Text = "Salvar";
            this.btn_Salvar.UseVisualStyleBackColor = true;
            this.btn_Salvar.Click += new System.EventHandler(this.btn_Salvar_Click);
            // 
            // menuStrip_Ope_Emp
            // 
            this.menuStrip_Ope_Emp.AutoSize = false;
            this.menuStrip_Ope_Emp.BackColor = System.Drawing.Color.DarkCyan;
            this.menuStrip_Ope_Emp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold);
            this.menuStrip_Ope_Emp.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip_Ope_Emp.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem_Emprestar_Jogos,
            this.ToolStripMenuItem_Procurar_Empréstimo,
            this.ToolStripMenuItem_Imp_Emprestimo});
            this.menuStrip_Ope_Emp.Location = new System.Drawing.Point(0, 0);
            this.menuStrip_Ope_Emp.Name = "menuStrip_Ope_Emp";
            this.menuStrip_Ope_Emp.Size = new System.Drawing.Size(995, 39);
            this.menuStrip_Ope_Emp.TabIndex = 58;
            this.menuStrip_Ope_Emp.Text = "menuStrip1";
            // 
            // ToolStripMenuItem_Emprestar_Jogos
            // 
            this.ToolStripMenuItem_Emprestar_Jogos.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator1});
            this.ToolStripMenuItem_Emprestar_Jogos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold);
            this.ToolStripMenuItem_Emprestar_Jogos.Name = "ToolStripMenuItem_Emprestar_Jogos";
            this.ToolStripMenuItem_Emprestar_Jogos.Size = new System.Drawing.Size(196, 35);
            this.ToolStripMenuItem_Emprestar_Jogos.Text = "Empréstimo de Jogos";
            this.ToolStripMenuItem_Emprestar_Jogos.Click += new System.EventHandler(this.ToolStripMenuItem_Emprestar_Jogos_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(221, 6);
            // 
            // ToolStripMenuItem_Procurar_Empréstimo
            // 
            this.ToolStripMenuItem_Procurar_Empréstimo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold);
            this.ToolStripMenuItem_Procurar_Empréstimo.Name = "ToolStripMenuItem_Procurar_Empréstimo";
            this.ToolStripMenuItem_Procurar_Empréstimo.Size = new System.Drawing.Size(200, 35);
            this.ToolStripMenuItem_Procurar_Empréstimo.Text = "Procurar Empréstimos";
            this.ToolStripMenuItem_Procurar_Empréstimo.Click += new System.EventHandler(this.ToolStripMenuItem_Procurar_Empréstimo_Click);
            // 
            // ToolStripMenuItem_Imp_Emprestimo
            // 
            this.ToolStripMenuItem_Imp_Emprestimo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold);
            this.ToolStripMenuItem_Imp_Emprestimo.Name = "ToolStripMenuItem_Imp_Emprestimo";
            this.ToolStripMenuItem_Imp_Emprestimo.Size = new System.Drawing.Size(265, 35);
            this.ToolStripMenuItem_Imp_Emprestimo.Text = "Imprimir Relatório Empréstimo";
            this.ToolStripMenuItem_Imp_Emprestimo.Click += new System.EventHandler(this.ToolStripMenuItem_Imp_Emprestimo_Click);
            // 
            // Frm_OperacoesEmp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(995, 548);
            this.Controls.Add(this.menuStrip_Ope_Emp);
            this.Controls.Add(this.btn_Salvar);
            this.Controls.Add(this.groupBoxEmpréstimos);
            this.Controls.Add(this.btn_Cancelar);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Frm_OperacoesEmp";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Locadora : Operações : Empréstimos";
            this.Load += new System.EventHandler(this.Frm_OperacoesEmp_Load);
            this.groupBoxEmpréstimos.ResumeLayout(false);
            this.groupBoxEmpréstimos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Jogos)).EndInit();
            this.menuStrip_Ope_Emp.ResumeLayout(false);
            this.menuStrip_Ope_Emp.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label lbl_ID_Operacoes;
        private System.Windows.Forms.TextBox txt_ID_Operacoes;
        private System.Windows.Forms.Label ID_Clientes;
        private System.Windows.Forms.Label lbl_Valor_Total;
        private System.Windows.Forms.Label lD_Jogos;
        private System.Windows.Forms.Label lbl_Data_de_Locacao;
        private System.Windows.Forms.GroupBox groupBoxEmpréstimos;
        private System.Windows.Forms.Button btn_Cancelar;
        private System.Windows.Forms.Button btn_Salvar;
        private System.Windows.Forms.MaskedTextBox maskedTextBox_Data_de_Locacao;
        private System.Windows.Forms.MenuStrip menuStrip_Ope_Emp;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_Emprestar_Jogos;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_Procurar_Empréstimo;
        private System.Windows.Forms.TextBox txt_Valor_Total;
        private System.Windows.Forms.Button btn_Anterior;
        private System.Windows.Forms.Button btn_Proximo;
        private System.Windows.Forms.DataGridView dataGridView_Jogos;
        private System.Windows.Forms.DataGridViewCheckBoxColumn select;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_Imp_Emprestimo;
        private System.Windows.Forms.ListBox Escolher_Cliente;
    }
}