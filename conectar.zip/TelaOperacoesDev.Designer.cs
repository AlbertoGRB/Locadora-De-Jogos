﻿namespace Alberto_Gabriel
{
    partial class Frm_OperacoesDev
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_OperacoesDev));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_Juros = new System.Windows.Forms.TextBox();
            this.dataGridView_Jogos = new System.Windows.Forms.DataGridView();
            this.select = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_Anterior = new System.Windows.Forms.Button();
            this.btn_Proximo = new System.Windows.Forms.Button();
            this.maskedTextBox_Data_de_Devolucao = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox_Data_de_Locacao = new System.Windows.Forms.MaskedTextBox();
            this.ID_Clientes = new System.Windows.Forms.Label();
            this.lbl_ID_Operacoes = new System.Windows.Forms.Label();
            this.txt_Valor_Total = new System.Windows.Forms.TextBox();
            this.lbl_Data_de_Devolucao = new System.Windows.Forms.Label();
            this.txt_ID_Operacoes = new System.Windows.Forms.TextBox();
            this.lbl_Valor_Total = new System.Windows.Forms.Label();
            this.lbl_Data_de_Locacao = new System.Windows.Forms.Label();
            this.lD_Jogos = new System.Windows.Forms.Label();
            this.txt_ID_Clientes = new System.Windows.Forms.TextBox();
            this.btn_Salvar = new System.Windows.Forms.Button();
            this.btn_Cancelar = new System.Windows.Forms.Button();
            this.menuStrip_Ope_Dev = new System.Windows.Forms.MenuStrip();
            this.ToolStripMenuItem_Devolver_Jogos = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_Imp_Devolucao = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Jogos)).BeginInit();
            this.menuStrip_Ope_Dev.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txt_Juros);
            this.groupBox1.Controls.Add(this.dataGridView_Jogos);
            this.groupBox1.Controls.Add(this.btn_Anterior);
            this.groupBox1.Controls.Add(this.btn_Proximo);
            this.groupBox1.Controls.Add(this.maskedTextBox_Data_de_Devolucao);
            this.groupBox1.Controls.Add(this.maskedTextBox_Data_de_Locacao);
            this.groupBox1.Controls.Add(this.ID_Clientes);
            this.groupBox1.Controls.Add(this.lbl_ID_Operacoes);
            this.groupBox1.Controls.Add(this.txt_Valor_Total);
            this.groupBox1.Controls.Add(this.lbl_Data_de_Devolucao);
            this.groupBox1.Controls.Add(this.txt_ID_Operacoes);
            this.groupBox1.Controls.Add(this.lbl_Valor_Total);
            this.groupBox1.Controls.Add(this.lbl_Data_de_Locacao);
            this.groupBox1.Controls.Add(this.lD_Jogos);
            this.groupBox1.Controls.Add(this.txt_ID_Clientes);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.groupBox1.ForeColor = System.Drawing.Color.DarkCyan;
            this.groupBox1.Location = new System.Drawing.Point(16, 69);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(963, 329);
            this.groupBox1.TabIndex = 51;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "DADOS DOS EMPRÉSTIMOS";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(457, 155);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 20);
            this.label1.TabIndex = 66;
            this.label1.Text = "Juros:";
            this.label1.Visible = false;
            // 
            // txt_Juros
            // 
            this.txt_Juros.Enabled = false;
            this.txt_Juros.Location = new System.Drawing.Point(461, 178);
            this.txt_Juros.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Juros.Name = "txt_Juros";
            this.txt_Juros.Size = new System.Drawing.Size(72, 24);
            this.txt_Juros.TabIndex = 65;
            this.txt_Juros.Visible = false;
            // 
            // dataGridView_Jogos
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dataGridView_Jogos.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_Jogos.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView_Jogos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_Jogos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView_Jogos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Jogos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.select});
            this.dataGridView_Jogos.Location = new System.Drawing.Point(8, 101);
            this.dataGridView_Jogos.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView_Jogos.Name = "dataGridView_Jogos";
            this.dataGridView_Jogos.RowHeadersVisible = false;
            this.dataGridView_Jogos.RowHeadersWidth = 45;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dataGridView_Jogos.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView_Jogos.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dataGridView_Jogos.Size = new System.Drawing.Size(445, 208);
            this.dataGridView_Jogos.TabIndex = 64;
            // 
            // select
            // 
            this.select.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.select.HeaderText = "";
            this.select.MinimumWidth = 6;
            this.select.Name = "select";
            this.select.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.select.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.select.Width = 24;
            // 
            // btn_Anterior
            // 
            this.btn_Anterior.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_Anterior.ForeColor = System.Drawing.Color.DarkCyan;
            this.btn_Anterior.Location = new System.Drawing.Point(461, 282);
            this.btn_Anterior.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Anterior.Name = "btn_Anterior";
            this.btn_Anterior.Size = new System.Drawing.Size(120, 27);
            this.btn_Anterior.TabIndex = 63;
            this.btn_Anterior.Text = "Anterior";
            this.btn_Anterior.UseVisualStyleBackColor = true;
            this.btn_Anterior.Click += new System.EventHandler(this.btn_Anterior_Click);
            // 
            // btn_Proximo
            // 
            this.btn_Proximo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_Proximo.ForeColor = System.Drawing.Color.DarkCyan;
            this.btn_Proximo.Location = new System.Drawing.Point(461, 247);
            this.btn_Proximo.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Proximo.Name = "btn_Proximo";
            this.btn_Proximo.Size = new System.Drawing.Size(120, 27);
            this.btn_Proximo.TabIndex = 62;
            this.btn_Proximo.Text = "Próximo";
            this.btn_Proximo.UseVisualStyleBackColor = true;
            this.btn_Proximo.Click += new System.EventHandler(this.btn_Proximo_Click);
            // 
            // maskedTextBox_Data_de_Devolucao
            // 
            this.maskedTextBox_Data_de_Devolucao.Location = new System.Drawing.Point(733, 48);
            this.maskedTextBox_Data_de_Devolucao.Margin = new System.Windows.Forms.Padding(4);
            this.maskedTextBox_Data_de_Devolucao.Mask = "00/00/0000";
            this.maskedTextBox_Data_de_Devolucao.Name = "maskedTextBox_Data_de_Devolucao";
            this.maskedTextBox_Data_de_Devolucao.Size = new System.Drawing.Size(108, 24);
            this.maskedTextBox_Data_de_Devolucao.TabIndex = 51;
            this.maskedTextBox_Data_de_Devolucao.ValidatingType = typeof(System.DateTime);
            // 
            // maskedTextBox_Data_de_Locacao
            // 
            this.maskedTextBox_Data_de_Locacao.Enabled = false;
            this.maskedTextBox_Data_de_Locacao.Location = new System.Drawing.Point(552, 48);
            this.maskedTextBox_Data_de_Locacao.Margin = new System.Windows.Forms.Padding(4);
            this.maskedTextBox_Data_de_Locacao.Mask = "00/00/0000";
            this.maskedTextBox_Data_de_Locacao.Name = "maskedTextBox_Data_de_Locacao";
            this.maskedTextBox_Data_de_Locacao.Size = new System.Drawing.Size(105, 24);
            this.maskedTextBox_Data_de_Locacao.TabIndex = 50;
            this.maskedTextBox_Data_de_Locacao.ValidatingType = typeof(System.DateTime);
            // 
            // ID_Clientes
            // 
            this.ID_Clientes.AutoSize = true;
            this.ID_Clientes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.ID_Clientes.ForeColor = System.Drawing.Color.Black;
            this.ID_Clientes.Location = new System.Drawing.Point(167, 25);
            this.ID_Clientes.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ID_Clientes.Name = "ID_Clientes";
            this.ID_Clientes.Size = new System.Drawing.Size(154, 20);
            this.ID_Clientes.TabIndex = 39;
            this.ID_Clientes.Text = "Nome do Cliente:";
            // 
            // lbl_ID_Operacoes
            // 
            this.lbl_ID_Operacoes.AutoSize = true;
            this.lbl_ID_Operacoes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_ID_Operacoes.ForeColor = System.Drawing.Color.Black;
            this.lbl_ID_Operacoes.Location = new System.Drawing.Point(4, 25);
            this.lbl_ID_Operacoes.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_ID_Operacoes.Name = "lbl_ID_Operacoes";
            this.lbl_ID_Operacoes.Size = new System.Drawing.Size(131, 20);
            this.lbl_ID_Operacoes.TabIndex = 37;
            this.lbl_ID_Operacoes.Text = "ID Operações:";
            // 
            // txt_Valor_Total
            // 
            this.txt_Valor_Total.Enabled = false;
            this.txt_Valor_Total.Location = new System.Drawing.Point(461, 126);
            this.txt_Valor_Total.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Valor_Total.Name = "txt_Valor_Total";
            this.txt_Valor_Total.Size = new System.Drawing.Size(227, 24);
            this.txt_Valor_Total.TabIndex = 38;
            // 
            // lbl_Data_de_Devolucao
            // 
            this.lbl_Data_de_Devolucao.AutoSize = true;
            this.lbl_Data_de_Devolucao.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Data_de_Devolucao.ForeColor = System.Drawing.Color.Black;
            this.lbl_Data_de_Devolucao.Location = new System.Drawing.Point(729, 25);
            this.lbl_Data_de_Devolucao.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Data_de_Devolucao.Name = "lbl_Data_de_Devolucao";
            this.lbl_Data_de_Devolucao.Size = new System.Drawing.Size(175, 20);
            this.lbl_Data_de_Devolucao.TabIndex = 47;
            this.lbl_Data_de_Devolucao.Text = "Data de Devolução:";
            // 
            // txt_ID_Operacoes
            // 
            this.txt_ID_Operacoes.Enabled = false;
            this.txt_ID_Operacoes.Location = new System.Drawing.Point(8, 48);
            this.txt_ID_Operacoes.Margin = new System.Windows.Forms.Padding(4);
            this.txt_ID_Operacoes.Name = "txt_ID_Operacoes";
            this.txt_ID_Operacoes.Size = new System.Drawing.Size(153, 24);
            this.txt_ID_Operacoes.TabIndex = 40;
            // 
            // lbl_Valor_Total
            // 
            this.lbl_Valor_Total.AutoSize = true;
            this.lbl_Valor_Total.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Valor_Total.ForeColor = System.Drawing.Color.Black;
            this.lbl_Valor_Total.Location = new System.Drawing.Point(461, 102);
            this.lbl_Valor_Total.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Valor_Total.Name = "lbl_Valor_Total";
            this.lbl_Valor_Total.Size = new System.Drawing.Size(210, 20);
            this.lbl_Valor_Total.TabIndex = 41;
            this.lbl_Valor_Total.Text = "Valor Total da Locação:";
            // 
            // lbl_Data_de_Locacao
            // 
            this.lbl_Data_de_Locacao.AutoSize = true;
            this.lbl_Data_de_Locacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Data_de_Locacao.ForeColor = System.Drawing.Color.Black;
            this.lbl_Data_de_Locacao.Location = new System.Drawing.Point(548, 25);
            this.lbl_Data_de_Locacao.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Data_de_Locacao.Name = "lbl_Data_de_Locacao";
            this.lbl_Data_de_Locacao.Size = new System.Drawing.Size(158, 20);
            this.lbl_Data_de_Locacao.TabIndex = 45;
            this.lbl_Data_de_Locacao.Text = "Data de Locação:";
            // 
            // lD_Jogos
            // 
            this.lD_Jogos.AutoSize = true;
            this.lD_Jogos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lD_Jogos.ForeColor = System.Drawing.Color.Black;
            this.lD_Jogos.Location = new System.Drawing.Point(4, 78);
            this.lD_Jogos.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lD_Jogos.Name = "lD_Jogos";
            this.lD_Jogos.Size = new System.Drawing.Size(90, 20);
            this.lD_Jogos.TabIndex = 43;
            this.lD_Jogos.Text = "ID Jogos:";
            // 
            // txt_ID_Clientes
            // 
            this.txt_ID_Clientes.Enabled = false;
            this.txt_ID_Clientes.Location = new System.Drawing.Point(171, 48);
            this.txt_ID_Clientes.Margin = new System.Windows.Forms.Padding(4);
            this.txt_ID_Clientes.Name = "txt_ID_Clientes";
            this.txt_ID_Clientes.Size = new System.Drawing.Size(363, 24);
            this.txt_ID_Clientes.TabIndex = 44;
            // 
            // btn_Salvar
            // 
            this.btn_Salvar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_Salvar.ForeColor = System.Drawing.Color.DarkCyan;
            this.btn_Salvar.Location = new System.Drawing.Point(859, 454);
            this.btn_Salvar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Salvar.Name = "btn_Salvar";
            this.btn_Salvar.Size = new System.Drawing.Size(120, 36);
            this.btn_Salvar.TabIndex = 56;
            this.btn_Salvar.Text = "Salvar";
            this.btn_Salvar.UseVisualStyleBackColor = true;
            this.btn_Salvar.Click += new System.EventHandler(this.btn_Salvar_Click);
            // 
            // btn_Cancelar
            // 
            this.btn_Cancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_Cancelar.ForeColor = System.Drawing.Color.DarkCyan;
            this.btn_Cancelar.Location = new System.Drawing.Point(859, 497);
            this.btn_Cancelar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Cancelar.Name = "btn_Cancelar";
            this.btn_Cancelar.Size = new System.Drawing.Size(120, 36);
            this.btn_Cancelar.TabIndex = 52;
            this.btn_Cancelar.Text = "Cancelar";
            this.btn_Cancelar.UseVisualStyleBackColor = true;
            this.btn_Cancelar.Click += new System.EventHandler(this.btn_Cancelar_Click);
            // 
            // menuStrip_Ope_Dev
            // 
            this.menuStrip_Ope_Dev.AutoSize = false;
            this.menuStrip_Ope_Dev.BackColor = System.Drawing.Color.DarkCyan;
            this.menuStrip_Ope_Dev.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold);
            this.menuStrip_Ope_Dev.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip_Ope_Dev.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem_Devolver_Jogos,
            this.toolStripMenuItem1,
            this.ToolStripMenuItem_Imp_Devolucao});
            this.menuStrip_Ope_Dev.Location = new System.Drawing.Point(0, 0);
            this.menuStrip_Ope_Dev.Name = "menuStrip_Ope_Dev";
            this.menuStrip_Ope_Dev.Size = new System.Drawing.Size(995, 39);
            this.menuStrip_Ope_Dev.TabIndex = 57;
            this.menuStrip_Ope_Dev.Text = "menuStrip1";
            // 
            // ToolStripMenuItem_Devolver_Jogos
            // 
            this.ToolStripMenuItem_Devolver_Jogos.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator1});
            this.ToolStripMenuItem_Devolver_Jogos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold);
            this.ToolStripMenuItem_Devolver_Jogos.Name = "ToolStripMenuItem_Devolver_Jogos";
            this.ToolStripMenuItem_Devolver_Jogos.Size = new System.Drawing.Size(185, 35);
            this.ToolStripMenuItem_Devolver_Jogos.Text = "Devolução de Jogos";
            this.ToolStripMenuItem_Devolver_Jogos.Click += new System.EventHandler(this.ToolStripMenuItem_Devolver_Jogos_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(71, 6);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold);
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(189, 35);
            this.toolStripMenuItem1.Text = "Procurar Devoluções";
            // 
            // ToolStripMenuItem_Imp_Devolucao
            // 
            this.ToolStripMenuItem_Imp_Devolucao.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold);
            this.ToolStripMenuItem_Imp_Devolucao.Name = "ToolStripMenuItem_Imp_Devolucao";
            this.ToolStripMenuItem_Imp_Devolucao.Size = new System.Drawing.Size(263, 35);
            this.ToolStripMenuItem_Imp_Devolucao.Text = "Imprimir Relatório Devoluções";
            this.ToolStripMenuItem_Imp_Devolucao.Click += new System.EventHandler(this.ToolStripMenuItem_Imp_Devolucao_Click);
            // 
            // Frm_OperacoesDev
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(995, 548);
            this.Controls.Add(this.menuStrip_Ope_Dev);
            this.Controls.Add(this.btn_Salvar);
            this.Controls.Add(this.btn_Cancelar);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Frm_OperacoesDev";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Locadora : Operações : Devoluções";
            this.Load += new System.EventHandler(this.Frm_OperacoesDev_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Jogos)).EndInit();
            this.menuStrip_Ope_Dev.ResumeLayout(false);
            this.menuStrip_Ope_Dev.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label ID_Clientes;
        private System.Windows.Forms.Label lbl_ID_Operacoes;
        private System.Windows.Forms.TextBox txt_Valor_Total;
        private System.Windows.Forms.Label lbl_Data_de_Devolucao;
        private System.Windows.Forms.TextBox txt_ID_Operacoes;
        private System.Windows.Forms.Label lbl_Valor_Total;
        private System.Windows.Forms.Label lbl_Data_de_Locacao;
        private System.Windows.Forms.Label lD_Jogos;
        private System.Windows.Forms.TextBox txt_ID_Clientes;
        private System.Windows.Forms.Button btn_Salvar;
        private System.Windows.Forms.Button btn_Cancelar;
        private System.Windows.Forms.MaskedTextBox maskedTextBox_Data_de_Locacao;
        private System.Windows.Forms.MaskedTextBox maskedTextBox_Data_de_Devolucao;
        private System.Windows.Forms.MenuStrip menuStrip_Ope_Dev;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_Imp_Devolucao;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_Devolver_Jogos;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.Button btn_Anterior;
        private System.Windows.Forms.Button btn_Proximo;
        private System.Windows.Forms.DataGridView dataGridView_Jogos;
        private System.Windows.Forms.DataGridViewTextBoxColumn select;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.TextBox txt_Juros;
        private System.Windows.Forms.Label label1;
    }
}