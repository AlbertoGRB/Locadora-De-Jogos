﻿namespace Alberto_Gabriel
{
    partial class Frm_Jogos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_Jogos));
            this.txt_Nome = new System.Windows.Forms.TextBox();
            this.lbl_Nome = new System.Windows.Forms.Label();
            this.txt_ID = new System.Windows.Forms.TextBox();
            this.lbl_ID = new System.Windows.Forms.Label();
            this.txt_Desenvolvedor = new System.Windows.Forms.TextBox();
            this.lbl_Desenvolvedor = new System.Windows.Forms.Label();
            this.lbl_Data_de_Lançamento = new System.Windows.Forms.Label();
            this.lbl_Genero = new System.Windows.Forms.Label();
            this.groupBoxJogos = new System.Windows.Forms.GroupBox();
            this.Escolher_Genero = new System.Windows.Forms.CheckedListBox();
            this.btn_Anterior = new System.Windows.Forms.Button();
            this.btn_Proximo = new System.Windows.Forms.Button();
            this.maskedTextBox_Data_de_Lancamento = new System.Windows.Forms.MaskedTextBox();
            this.btn_Salvar = new System.Windows.Forms.Button();
            this.btn_Cancelar = new System.Windows.Forms.Button();
            this.menuStrip_Jogos = new System.Windows.Forms.MenuStrip();
            this.ToolStripMenuItem_Cadastrar = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_Alterar = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_Procurar = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_Excluir = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBoxJogos.SuspendLayout();
            this.menuStrip_Jogos.SuspendLayout();
            this.SuspendLayout();
            // 
            // txt_Nome
            // 
            this.txt_Nome.ForeColor = System.Drawing.Color.Black;
            this.txt_Nome.Location = new System.Drawing.Point(85, 57);
            this.txt_Nome.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Nome.Name = "txt_Nome";
            this.txt_Nome.Size = new System.Drawing.Size(419, 24);
            this.txt_Nome.TabIndex = 38;
            // 
            // lbl_Nome
            // 
            this.lbl_Nome.AutoSize = true;
            this.lbl_Nome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Nome.ForeColor = System.Drawing.Color.Black;
            this.lbl_Nome.Location = new System.Drawing.Point(81, 33);
            this.lbl_Nome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Nome.Name = "lbl_Nome";
            this.lbl_Nome.Size = new System.Drawing.Size(63, 20);
            this.lbl_Nome.TabIndex = 37;
            this.lbl_Nome.Text = "Nome:";
            // 
            // txt_ID
            // 
            this.txt_ID.Enabled = false;
            this.txt_ID.ForeColor = System.Drawing.Color.Black;
            this.txt_ID.Location = new System.Drawing.Point(8, 57);
            this.txt_ID.Margin = new System.Windows.Forms.Padding(4);
            this.txt_ID.Name = "txt_ID";
            this.txt_ID.Size = new System.Drawing.Size(68, 24);
            this.txt_ID.TabIndex = 36;
            // 
            // lbl_ID
            // 
            this.lbl_ID.AutoSize = true;
            this.lbl_ID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_ID.ForeColor = System.Drawing.Color.Black;
            this.lbl_ID.Location = new System.Drawing.Point(4, 33);
            this.lbl_ID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_ID.Name = "lbl_ID";
            this.lbl_ID.Size = new System.Drawing.Size(34, 20);
            this.lbl_ID.TabIndex = 35;
            this.lbl_ID.Text = "ID:";
            // 
            // txt_Desenvolvedor
            // 
            this.txt_Desenvolvedor.ForeColor = System.Drawing.Color.Black;
            this.txt_Desenvolvedor.Location = new System.Drawing.Point(513, 57);
            this.txt_Desenvolvedor.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Desenvolvedor.Name = "txt_Desenvolvedor";
            this.txt_Desenvolvedor.Size = new System.Drawing.Size(419, 24);
            this.txt_Desenvolvedor.TabIndex = 43;
            // 
            // lbl_Desenvolvedor
            // 
            this.lbl_Desenvolvedor.AutoSize = true;
            this.lbl_Desenvolvedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Desenvolvedor.ForeColor = System.Drawing.Color.Black;
            this.lbl_Desenvolvedor.Location = new System.Drawing.Point(509, 33);
            this.lbl_Desenvolvedor.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Desenvolvedor.Name = "lbl_Desenvolvedor";
            this.lbl_Desenvolvedor.Size = new System.Drawing.Size(139, 20);
            this.lbl_Desenvolvedor.TabIndex = 42;
            this.lbl_Desenvolvedor.Text = "Desenvolvedor:";
            // 
            // lbl_Data_de_Lançamento
            // 
            this.lbl_Data_de_Lançamento.AutoSize = true;
            this.lbl_Data_de_Lançamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Data_de_Lançamento.ForeColor = System.Drawing.Color.Black;
            this.lbl_Data_de_Lançamento.Location = new System.Drawing.Point(201, 86);
            this.lbl_Data_de_Lançamento.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Data_de_Lançamento.Name = "lbl_Data_de_Lançamento";
            this.lbl_Data_de_Lançamento.Size = new System.Drawing.Size(189, 20);
            this.lbl_Data_de_Lançamento.TabIndex = 39;
            this.lbl_Data_de_Lançamento.Text = "Data de Lançamento:";
            // 
            // lbl_Genero
            // 
            this.lbl_Genero.AutoSize = true;
            this.lbl_Genero.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Genero.ForeColor = System.Drawing.Color.Black;
            this.lbl_Genero.Location = new System.Drawing.Point(4, 86);
            this.lbl_Genero.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Genero.Name = "lbl_Genero";
            this.lbl_Genero.Size = new System.Drawing.Size(76, 20);
            this.lbl_Genero.TabIndex = 46;
            this.lbl_Genero.Text = "Gênero:";
            // 
            // groupBoxJogos
            // 
            this.groupBoxJogos.Controls.Add(this.Escolher_Genero);
            this.groupBoxJogos.Controls.Add(this.btn_Anterior);
            this.groupBoxJogos.Controls.Add(this.btn_Proximo);
            this.groupBoxJogos.Controls.Add(this.maskedTextBox_Data_de_Lancamento);
            this.groupBoxJogos.Controls.Add(this.txt_ID);
            this.groupBoxJogos.Controls.Add(this.lbl_Genero);
            this.groupBoxJogos.Controls.Add(this.lbl_ID);
            this.groupBoxJogos.Controls.Add(this.lbl_Nome);
            this.groupBoxJogos.Controls.Add(this.txt_Desenvolvedor);
            this.groupBoxJogos.Controls.Add(this.txt_Nome);
            this.groupBoxJogos.Controls.Add(this.lbl_Desenvolvedor);
            this.groupBoxJogos.Controls.Add(this.lbl_Data_de_Lançamento);
            this.groupBoxJogos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.groupBoxJogos.ForeColor = System.Drawing.Color.DarkCyan;
            this.groupBoxJogos.Location = new System.Drawing.Point(16, 69);
            this.groupBoxJogos.Margin = new System.Windows.Forms.Padding(4);
            this.groupBoxJogos.Name = "groupBoxJogos";
            this.groupBoxJogos.Padding = new System.Windows.Forms.Padding(4);
            this.groupBoxJogos.Size = new System.Drawing.Size(944, 256);
            this.groupBoxJogos.TabIndex = 47;
            this.groupBoxJogos.TabStop = false;
            this.groupBoxJogos.Text = "DADOS DOS JOGOS";
            // 
            // Escolher_Genero
            // 
            this.Escolher_Genero.FormattingEnabled = true;
            this.Escolher_Genero.Location = new System.Drawing.Point(8, 110);
            this.Escolher_Genero.Margin = new System.Windows.Forms.Padding(4);
            this.Escolher_Genero.Name = "Escolher_Genero";
            this.Escolher_Genero.Size = new System.Drawing.Size(184, 118);
            this.Escolher_Genero.TabIndex = 62;
            // 
            // btn_Anterior
            // 
            this.btn_Anterior.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_Anterior.ForeColor = System.Drawing.Color.DarkCyan;
            this.btn_Anterior.Location = new System.Drawing.Point(816, 206);
            this.btn_Anterior.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Anterior.Name = "btn_Anterior";
            this.btn_Anterior.Size = new System.Drawing.Size(120, 27);
            this.btn_Anterior.TabIndex = 61;
            this.btn_Anterior.Text = "Anterior";
            this.btn_Anterior.UseVisualStyleBackColor = true;
            this.btn_Anterior.Click += new System.EventHandler(this.btn_Anterior_Click);
            // 
            // btn_Proximo
            // 
            this.btn_Proximo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_Proximo.ForeColor = System.Drawing.Color.DarkCyan;
            this.btn_Proximo.Location = new System.Drawing.Point(816, 171);
            this.btn_Proximo.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Proximo.Name = "btn_Proximo";
            this.btn_Proximo.Size = new System.Drawing.Size(120, 27);
            this.btn_Proximo.TabIndex = 60;
            this.btn_Proximo.Text = "Próximo";
            this.btn_Proximo.UseVisualStyleBackColor = true;
            this.btn_Proximo.Click += new System.EventHandler(this.btn_Proximo_Click);
            // 
            // maskedTextBox_Data_de_Lancamento
            // 
            this.maskedTextBox_Data_de_Lancamento.Location = new System.Drawing.Point(201, 110);
            this.maskedTextBox_Data_de_Lancamento.Margin = new System.Windows.Forms.Padding(4);
            this.maskedTextBox_Data_de_Lancamento.Mask = "00/00/0000";
            this.maskedTextBox_Data_de_Lancamento.Name = "maskedTextBox_Data_de_Lancamento";
            this.maskedTextBox_Data_de_Lancamento.Size = new System.Drawing.Size(131, 24);
            this.maskedTextBox_Data_de_Lancamento.TabIndex = 52;
            this.maskedTextBox_Data_de_Lancamento.ValidatingType = typeof(System.DateTime);
            // 
            // btn_Salvar
            // 
            this.btn_Salvar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_Salvar.ForeColor = System.Drawing.Color.DarkCyan;
            this.btn_Salvar.Location = new System.Drawing.Point(859, 454);
            this.btn_Salvar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Salvar.Name = "btn_Salvar";
            this.btn_Salvar.Size = new System.Drawing.Size(120, 36);
            this.btn_Salvar.TabIndex = 48;
            this.btn_Salvar.Text = "Salvar";
            this.btn_Salvar.UseVisualStyleBackColor = true;
            this.btn_Salvar.Click += new System.EventHandler(this.btn_Salvar_Click);
            // 
            // btn_Cancelar
            // 
            this.btn_Cancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_Cancelar.ForeColor = System.Drawing.Color.DarkCyan;
            this.btn_Cancelar.Location = new System.Drawing.Point(859, 497);
            this.btn_Cancelar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Cancelar.Name = "btn_Cancelar";
            this.btn_Cancelar.Size = new System.Drawing.Size(120, 36);
            this.btn_Cancelar.TabIndex = 1;
            this.btn_Cancelar.Text = "Cancelar";
            this.btn_Cancelar.UseVisualStyleBackColor = true;
            this.btn_Cancelar.Click += new System.EventHandler(this.btn_Sair_Click);
            // 
            // menuStrip_Jogos
            // 
            this.menuStrip_Jogos.AutoSize = false;
            this.menuStrip_Jogos.BackColor = System.Drawing.Color.DarkCyan;
            this.menuStrip_Jogos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold);
            this.menuStrip_Jogos.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip_Jogos.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem_Cadastrar,
            this.ToolStripMenuItem_Alterar,
            this.ToolStripMenuItem_Procurar,
            this.ToolStripMenuItem_Excluir});
            this.menuStrip_Jogos.Location = new System.Drawing.Point(0, 0);
            this.menuStrip_Jogos.Name = "menuStrip_Jogos";
            this.menuStrip_Jogos.Size = new System.Drawing.Size(995, 39);
            this.menuStrip_Jogos.TabIndex = 49;
            this.menuStrip_Jogos.Text = "menuStrip1";
            // 
            // ToolStripMenuItem_Cadastrar
            // 
            this.ToolStripMenuItem_Cadastrar.AutoSize = false;
            this.ToolStripMenuItem_Cadastrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold);
            this.ToolStripMenuItem_Cadastrar.Name = "ToolStripMenuItem_Cadastrar";
            this.ToolStripMenuItem_Cadastrar.Size = new System.Drawing.Size(87, 28);
            this.ToolStripMenuItem_Cadastrar.Text = "Cadastrar";
            this.ToolStripMenuItem_Cadastrar.Click += new System.EventHandler(this.ToolStripMenuItem_Cadastrar_Click);
            // 
            // ToolStripMenuItem_Alterar
            // 
            this.ToolStripMenuItem_Alterar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold);
            this.ToolStripMenuItem_Alterar.Name = "ToolStripMenuItem_Alterar";
            this.ToolStripMenuItem_Alterar.Size = new System.Drawing.Size(77, 35);
            this.ToolStripMenuItem_Alterar.Text = "Alterar";
            this.ToolStripMenuItem_Alterar.Click += new System.EventHandler(this.ToolStripMenuItem_Alterar_Click);
            // 
            // ToolStripMenuItem_Procurar
            // 
            this.ToolStripMenuItem_Procurar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold);
            this.ToolStripMenuItem_Procurar.Name = "ToolStripMenuItem_Procurar";
            this.ToolStripMenuItem_Procurar.Size = new System.Drawing.Size(144, 35);
            this.ToolStripMenuItem_Procurar.Text = "Procurar Jogos";
            this.ToolStripMenuItem_Procurar.Click += new System.EventHandler(this.ToolStripMenuItem_Procurar_Click);
            // 
            // ToolStripMenuItem_Excluir
            // 
            this.ToolStripMenuItem_Excluir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold);
            this.ToolStripMenuItem_Excluir.ForeColor = System.Drawing.Color.Black;
            this.ToolStripMenuItem_Excluir.Name = "ToolStripMenuItem_Excluir";
            this.ToolStripMenuItem_Excluir.Size = new System.Drawing.Size(76, 35);
            this.ToolStripMenuItem_Excluir.Text = "Excluir";
            this.ToolStripMenuItem_Excluir.Click += new System.EventHandler(this.ToolStripMenuItem_Excluir_Click);
            // 
            // Frm_Jogos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(995, 548);
            this.Controls.Add(this.menuStrip_Jogos);
            this.Controls.Add(this.btn_Salvar);
            this.Controls.Add(this.groupBoxJogos);
            this.Controls.Add(this.btn_Cancelar);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Frm_Jogos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Locadora : Jogos";
            this.Load += new System.EventHandler(this.Frm_Jogos_Load);
            this.Click += new System.EventHandler(this.Frm_Jogos_Load);
            this.groupBoxJogos.ResumeLayout(false);
            this.groupBoxJogos.PerformLayout();
            this.menuStrip_Jogos.ResumeLayout(false);
            this.menuStrip_Jogos.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TextBox txt_Nome;
        private System.Windows.Forms.Label lbl_Nome;
        private System.Windows.Forms.TextBox txt_ID;
        private System.Windows.Forms.Label lbl_ID;
        private System.Windows.Forms.TextBox txt_Desenvolvedor;
        private System.Windows.Forms.Label lbl_Desenvolvedor;
        private System.Windows.Forms.Label lbl_Data_de_Lançamento;
        private System.Windows.Forms.Label lbl_Genero;
        private System.Windows.Forms.GroupBox groupBoxJogos;
        private System.Windows.Forms.Button btn_Salvar;
        private System.Windows.Forms.Button btn_Cancelar;
        private System.Windows.Forms.MaskedTextBox maskedTextBox_Data_de_Lancamento;
        private System.Windows.Forms.MenuStrip menuStrip_Jogos;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_Cadastrar;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_Alterar;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_Procurar;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_Excluir;
        private System.Windows.Forms.Button btn_Anterior;
        private System.Windows.Forms.Button btn_Proximo;
        private System.Windows.Forms.CheckedListBox Escolher_Genero;
    }
}