﻿using System;
using System.Windows.Forms;

namespace Alberto_Gabriel
{
    public partial class Frm_ProcurarJogos : Form
    {
        public Frm_ProcurarJogos()
        {
            InitializeComponent();
        }

        private void btn_Cancelar_Jogos_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_Procurar_Jogos_Click(object sender, EventArgs e)
        {
            conectar.nome_busca = txt_Procurar_Jogos.Text;
            this.Close();
        }
    }
}
