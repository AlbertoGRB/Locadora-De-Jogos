﻿namespace Alberto_Gabriel
{
    partial class Frm_Generos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_Generos));
            this.btn_Cancelar = new System.Windows.Forms.Button();
            this.txt_ID = new System.Windows.Forms.TextBox();
            this.lbl_ID = new System.Windows.Forms.Label();
            this.txt_Descricao = new System.Windows.Forms.TextBox();
            this.lbl_Descricao = new System.Windows.Forms.Label();
            this.btn_Salvar = new System.Windows.Forms.Button();
            this.groupBox_Generos = new System.Windows.Forms.GroupBox();
            this.btn_Anterior = new System.Windows.Forms.Button();
            this.btn_Proximo = new System.Windows.Forms.Button();
            this.menuStrip_Generos = new System.Windows.Forms.MenuStrip();
            this.ToolStripMenuItem_Cadastrar = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_Alterar = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_Procurar = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_Excluir = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox_Generos.SuspendLayout();
            this.menuStrip_Generos.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Cancelar
            // 
            this.btn_Cancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_Cancelar.ForeColor = System.Drawing.Color.DarkCyan;
            this.btn_Cancelar.Location = new System.Drawing.Point(859, 500);
            this.btn_Cancelar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Cancelar.Name = "btn_Cancelar";
            this.btn_Cancelar.Size = new System.Drawing.Size(120, 33);
            this.btn_Cancelar.TabIndex = 1;
            this.btn_Cancelar.Text = "Cancelar";
            this.btn_Cancelar.UseVisualStyleBackColor = true;
            this.btn_Cancelar.Click += new System.EventHandler(this.btn_Sair_Click);
            // 
            // txt_ID
            // 
            this.txt_ID.Enabled = false;
            this.txt_ID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txt_ID.Location = new System.Drawing.Point(8, 57);
            this.txt_ID.Margin = new System.Windows.Forms.Padding(4);
            this.txt_ID.Name = "txt_ID";
            this.txt_ID.Size = new System.Drawing.Size(107, 26);
            this.txt_ID.TabIndex = 38;
            // 
            // lbl_ID
            // 
            this.lbl_ID.AutoSize = true;
            this.lbl_ID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_ID.ForeColor = System.Drawing.Color.Black;
            this.lbl_ID.Location = new System.Drawing.Point(4, 33);
            this.lbl_ID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_ID.Name = "lbl_ID";
            this.lbl_ID.Size = new System.Drawing.Size(34, 20);
            this.lbl_ID.TabIndex = 37;
            this.lbl_ID.Text = "ID:";
            // 
            // txt_Descricao
            // 
            this.txt_Descricao.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txt_Descricao.Location = new System.Drawing.Point(124, 57);
            this.txt_Descricao.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Descricao.Multiline = true;
            this.txt_Descricao.Name = "txt_Descricao";
            this.txt_Descricao.Size = new System.Drawing.Size(403, 91);
            this.txt_Descricao.TabIndex = 45;
            // 
            // lbl_Descricao
            // 
            this.lbl_Descricao.AutoSize = true;
            this.lbl_Descricao.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Descricao.ForeColor = System.Drawing.Color.Black;
            this.lbl_Descricao.Location = new System.Drawing.Point(120, 33);
            this.lbl_Descricao.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Descricao.Name = "lbl_Descricao";
            this.lbl_Descricao.Size = new System.Drawing.Size(101, 20);
            this.lbl_Descricao.TabIndex = 44;
            this.lbl_Descricao.Text = "Descrição:";
            // 
            // btn_Salvar
            // 
            this.btn_Salvar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_Salvar.ForeColor = System.Drawing.Color.DarkCyan;
            this.btn_Salvar.Location = new System.Drawing.Point(859, 457);
            this.btn_Salvar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Salvar.Name = "btn_Salvar";
            this.btn_Salvar.Size = new System.Drawing.Size(120, 36);
            this.btn_Salvar.TabIndex = 46;
            this.btn_Salvar.Text = "Salvar";
            this.btn_Salvar.UseVisualStyleBackColor = true;
            this.btn_Salvar.Click += new System.EventHandler(this.btn_Salvar_Click);
            // 
            // groupBox_Generos
            // 
            this.groupBox_Generos.Controls.Add(this.btn_Anterior);
            this.groupBox_Generos.Controls.Add(this.btn_Proximo);
            this.groupBox_Generos.Controls.Add(this.txt_Descricao);
            this.groupBox_Generos.Controls.Add(this.lbl_ID);
            this.groupBox_Generos.Controls.Add(this.txt_ID);
            this.groupBox_Generos.Controls.Add(this.lbl_Descricao);
            this.groupBox_Generos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.groupBox_Generos.ForeColor = System.Drawing.Color.DarkCyan;
            this.groupBox_Generos.Location = new System.Drawing.Point(16, 69);
            this.groupBox_Generos.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox_Generos.Name = "groupBox_Generos";
            this.groupBox_Generos.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox_Generos.Size = new System.Drawing.Size(720, 162);
            this.groupBox_Generos.TabIndex = 47;
            this.groupBox_Generos.TabStop = false;
            this.groupBox_Generos.Text = "DADOS DOS GÊNEROS";
            // 
            // btn_Anterior
            // 
            this.btn_Anterior.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_Anterior.ForeColor = System.Drawing.Color.DarkCyan;
            this.btn_Anterior.Location = new System.Drawing.Point(592, 123);
            this.btn_Anterior.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Anterior.Name = "btn_Anterior";
            this.btn_Anterior.Size = new System.Drawing.Size(120, 27);
            this.btn_Anterior.TabIndex = 59;
            this.btn_Anterior.Text = "Anterior";
            this.btn_Anterior.UseVisualStyleBackColor = true;
            this.btn_Anterior.Click += new System.EventHandler(this.btn_Anterior_Click);
            // 
            // btn_Proximo
            // 
            this.btn_Proximo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_Proximo.ForeColor = System.Drawing.Color.DarkCyan;
            this.btn_Proximo.Location = new System.Drawing.Point(592, 89);
            this.btn_Proximo.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Proximo.Name = "btn_Proximo";
            this.btn_Proximo.Size = new System.Drawing.Size(120, 27);
            this.btn_Proximo.TabIndex = 58;
            this.btn_Proximo.Text = "Próximo";
            this.btn_Proximo.UseVisualStyleBackColor = true;
            this.btn_Proximo.Click += new System.EventHandler(this.btn_Proximo_Click);
            // 
            // menuStrip_Generos
            // 
            this.menuStrip_Generos.AutoSize = false;
            this.menuStrip_Generos.BackColor = System.Drawing.Color.DarkCyan;
            this.menuStrip_Generos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold);
            this.menuStrip_Generos.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip_Generos.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem_Cadastrar,
            this.ToolStripMenuItem_Alterar,
            this.ToolStripMenuItem_Procurar,
            this.ToolStripMenuItem_Excluir});
            this.menuStrip_Generos.Location = new System.Drawing.Point(0, 0);
            this.menuStrip_Generos.Name = "menuStrip_Generos";
            this.menuStrip_Generos.Size = new System.Drawing.Size(995, 39);
            this.menuStrip_Generos.TabIndex = 48;
            this.menuStrip_Generos.Text = "menuStrip1";
            // 
            // ToolStripMenuItem_Cadastrar
            // 
            this.ToolStripMenuItem_Cadastrar.AutoSize = false;
            this.ToolStripMenuItem_Cadastrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold);
            this.ToolStripMenuItem_Cadastrar.ForeColor = System.Drawing.Color.Black;
            this.ToolStripMenuItem_Cadastrar.Name = "ToolStripMenuItem_Cadastrar";
            this.ToolStripMenuItem_Cadastrar.Size = new System.Drawing.Size(87, 28);
            this.ToolStripMenuItem_Cadastrar.Text = "Cadastrar";
            this.ToolStripMenuItem_Cadastrar.Click += new System.EventHandler(this.ToolStripMenuItem_Cadastrar_Click);
            // 
            // ToolStripMenuItem_Alterar
            // 
            this.ToolStripMenuItem_Alterar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold);
            this.ToolStripMenuItem_Alterar.ForeColor = System.Drawing.Color.Black;
            this.ToolStripMenuItem_Alterar.Name = "ToolStripMenuItem_Alterar";
            this.ToolStripMenuItem_Alterar.Size = new System.Drawing.Size(77, 35);
            this.ToolStripMenuItem_Alterar.Text = "Alterar";
            this.ToolStripMenuItem_Alterar.Click += new System.EventHandler(this.ToolStripMenuItem_Alterar_Click);
            // 
            // ToolStripMenuItem_Procurar
            // 
            this.ToolStripMenuItem_Procurar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold);
            this.ToolStripMenuItem_Procurar.ForeColor = System.Drawing.Color.Black;
            this.ToolStripMenuItem_Procurar.Name = "ToolStripMenuItem_Procurar";
            this.ToolStripMenuItem_Procurar.Size = new System.Drawing.Size(156, 35);
            this.ToolStripMenuItem_Procurar.Text = "Procurar Gênero";
            this.ToolStripMenuItem_Procurar.Click += new System.EventHandler(this.ToolStripMenuItem_Procurar_Click);
            // 
            // ToolStripMenuItem_Excluir
            // 
            this.ToolStripMenuItem_Excluir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold);
            this.ToolStripMenuItem_Excluir.ForeColor = System.Drawing.Color.Black;
            this.ToolStripMenuItem_Excluir.Name = "ToolStripMenuItem_Excluir";
            this.ToolStripMenuItem_Excluir.Size = new System.Drawing.Size(76, 35);
            this.ToolStripMenuItem_Excluir.Text = "Excluir";
            this.ToolStripMenuItem_Excluir.Click += new System.EventHandler(this.ToolStripMenuItem_Excluir_Click);
            // 
            // Frm_Generos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(995, 548);
            this.Controls.Add(this.menuStrip_Generos);
            this.Controls.Add(this.groupBox_Generos);
            this.Controls.Add(this.btn_Salvar);
            this.Controls.Add(this.btn_Cancelar);
            this.ForeColor = System.Drawing.Color.Black;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Frm_Generos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Locadora : Gêneros";
            this.Load += new System.EventHandler(this.Frm_Generos_Load_1);
            this.groupBox_Generos.ResumeLayout(false);
            this.groupBox_Generos.PerformLayout();
            this.menuStrip_Generos.ResumeLayout(false);
            this.menuStrip_Generos.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Cancelar;
        private System.Windows.Forms.TextBox txt_ID;
        private System.Windows.Forms.Label lbl_ID;
        private System.Windows.Forms.TextBox txt_Descricao;
        private System.Windows.Forms.Label lbl_Descricao;
        private System.Windows.Forms.Button btn_Salvar;
        private System.Windows.Forms.GroupBox groupBox_Generos;
        private System.Windows.Forms.MenuStrip menuStrip_Generos;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_Cadastrar;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_Alterar;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_Procurar;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_Excluir;
        private System.Windows.Forms.Button btn_Anterior;
        private System.Windows.Forms.Button btn_Proximo;
    }
}