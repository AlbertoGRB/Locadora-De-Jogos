﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace Alberto_Gabriel
{
    public partial class Frm_Clientes : Form
    {
        public Frm_Clientes()
        {
            InitializeComponent();
        }

        private void ToolStripMenuItem_Cadastrar_Click(object sender, EventArgs e)
        {
            Limpa_Campos();
            txt_Nome.Focus();
        }

        private void ToolStripMenuItem_Alterar_Click(object sender, EventArgs e)
        {
            txt_Nome.Focus();
            MySqlConnection conexao = conectar.fazer_conexao();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = conexao;
            try
            {
                conexao.Open();
                cmd.CommandText = "Select * from clientes order by Nome limit 1";
                MySqlDataReader resultado = cmd.ExecuteReader();
                if (resultado.HasRows)
                {
                    resultado.Read();
                    txt_ID.Text = resultado["ID_clientes"].ToString();
                    txt_Nome.Text = resultado["Nome"].ToString();
                    txt_Documento.Text = resultado["Documento"].ToString();
                    maskedTextBox_Data_de_Nascimento.Text = resultado["Data_de_Nascimento"].ToString();
                    txt_Endereco.Text = resultado["Endereco"].ToString();
                    txt_Bairro.Text = resultado["Bairro"].ToString();
                    txt_Cidade.Text = resultado["Cidade"].ToString();
                    txt_Estado.Text = resultado["Estado"].ToString();
                    txt_CEP.Text = resultado["CEP"].ToString();
                    maskedTextBox_Celular.Text = resultado["Celular"].ToString();
                    txt_Email.Text = resultado["Email"].ToString();
                    txt_Observacao.Text = resultado["Observacoes"].ToString();
                }
                ChecaBotoes();
                conexao.Close();
            }
            catch (MySqlException err)
            {
                MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0); 
            }
        }
        
        private void ToolStripMenuItem_Procurar_Click(object sender, EventArgs e)
        {
            Frm_ProcurarClientes frm_ProcurarClientes = new Frm_ProcurarClientes();
            frm_ProcurarClientes.ShowDialog();
            if (conectar.nome_busca != "")
            {
                MySqlConnection conexao = conectar.fazer_conexao();
                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = conexao;
                try
                {
                    conexao.Open();
                    cmd.CommandText = "Select * from clientes where nome like '%" + conectar.nome_busca + "%' order by nome desc limit 1";
                    MySqlDataReader resultado = cmd.ExecuteReader();
                    if (resultado.HasRows)
                    {
                        resultado.Read();
                        txt_ID.Text = resultado["ID_clientes"].ToString();
                        txt_Nome.Text = resultado["Nome"].ToString();
                        txt_Documento.Text = resultado["Documento"].ToString();
                        maskedTextBox_Data_de_Nascimento.Text = resultado["Data_de_Nascimento"].ToString();
                        txt_Endereco.Text = resultado["Endereco"].ToString();
                        txt_Bairro.Text = resultado["Bairro"].ToString();
                        txt_Cidade.Text = resultado["Cidade"].ToString();
                        txt_Estado.Text = resultado["Estado"].ToString();
                        txt_CEP.Text = resultado["CEP"].ToString();
                        maskedTextBox_Celular.Text = resultado["Celular"].ToString();
                        txt_Email.Text = resultado["Email"].ToString();
                        txt_Observacao.Text = resultado["Observacoes"].ToString();
                    }
                    else
                    {
                        MessageBox.Show("Cliente" + conectar.nome_busca + " não encontrado", "Procurar : Clientes", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    ChecaBotoes();
                    conexao.Close();
                }
                catch (MySqlException err)
                {
                    MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Environment.Exit(0); 
                }
            }
        }

        private void ToolStripMenuItem_Excluir_Click(object sender, EventArgs e)
        {
            MySqlConnection conexao = conectar.fazer_conexao();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = conexao;
            try
            {
                conexao.Open();
              
                cmd.CommandText = "Select c.ID_clientes, e.ID_Clientes from clientes c, emprestimos e where c.ID_clientes = e.ID_Clientes and c.ID_clientes = " + txt_ID.Text;

                MySqlDataReader resp = cmd.ExecuteReader();
                if (resp.HasRows)
                {
                    MessageBox.Show("Há um empréstimo com esse nome \n Cliente não pode ser excluído", "Excluir", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    resp.Close();
                    cmd.CommandText = "Delete from clientes where ID_clientes = " + txt_ID.Text;
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Cliente foi excluído com sucesso", "Excluir", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Limpa_Campos();
                   
                }
                conexao.Close();
                ChecaBotoes();
            } 
            catch (MySqlException err)
            {
                MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0); 
            }
        }
       
        private void btn_Salvar_Click(object sender, EventArgs e)
        {
            MySqlConnection conexao = conectar.fazer_conexao();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = conexao;
            try
            {
                conexao.Open();
                if (txt_ID.Text == "")
                {
                    cmd.CommandText = "Insert into clientes (Nome, Documento, Data_de_Nascimento, Endereco, Bairro, CEP, Cidade, Estado, Celular, Email, Observacoes) values ('" + txt_Nome.Text + "','" + txt_Documento.Text + "','" + maskedTextBox_Data_de_Nascimento.Text + "','" + txt_Endereco.Text + "','" + txt_Bairro.Text + "','" + txt_Cidade.Text + "','" + txt_Estado.Text + "','" + txt_CEP.Text + "','" + maskedTextBox_Celular.Text + "','" + txt_Email.Text + "','" + txt_Observacao.Text + "')";
                }
                else
                cmd.CommandText = "Update clientes set Nome = '" + txt_Nome.Text + "', Documento = '" + txt_Documento.Text + "', Data_de_Nascimento = '" + maskedTextBox_Data_de_Nascimento.Text + "', Endereco = '" + txt_Endereco.Text + "', Bairro = '" + txt_Bairro.Text + "', Cidade = '" + txt_Cidade.Text + "', Estado = '" + txt_Estado.Text + "', CEP = '" + txt_CEP.Text + "', Celular = '" + maskedTextBox_Celular.Text + "', Email = '" + txt_Email.Text + "', Observacoes = '" + txt_Observacao.Text + "' where ID_clientes = " + txt_ID.Text;
                cmd.ExecuteNonQuery();
                conexao.Close();
                MessageBox.Show("Cliente salvo com sucesso!", "Salvar : Clientes", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Erro: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            try
            {
                conexao.Open();
                cmd.CommandText = "Select MAX(ID_clientes) from clientes";
                MySqlDataReader resultado = cmd.ExecuteReader();
                if (resultado.HasRows)
                {
                    resultado.Read();
                    txt_ID.Text = resultado["MAX(ID_clientes)"].ToString();
                }
               
                conexao.Close();
            }
            catch (MySqlException err)
            {
                MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0); 
            }
        }

        private void btn_Sair_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        
        private void btn_Proximo_Click(object sender, EventArgs e)
        {
            MySqlConnection conexao = conectar.fazer_conexao();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = conexao;
            try
            {
                conexao.Open();
                cmd.CommandText = "Select * from clientes where Nome > '" + txt_Nome.Text + "' order by nome limit 1";
                MySqlDataReader resultado = cmd.ExecuteReader();
                if (resultado.HasRows)
                {
                    resultado.Read();
                    txt_ID.Text = resultado["ID_clientes"].ToString();
                    txt_Nome.Text = resultado["Nome"].ToString();
                    txt_Documento.Text = resultado["Documento"].ToString();
                    maskedTextBox_Data_de_Nascimento.Text = resultado["Data_de_Nascimento"].ToString();
                    txt_Endereco.Text = resultado["Endereco"].ToString();
                    txt_Bairro.Text = resultado["Bairro"].ToString();
                    txt_Cidade.Text = resultado["Cidade"].ToString();
                    txt_Estado.Text = resultado["Estado"].ToString();
                    txt_CEP.Text = resultado["CEP"].ToString();
                    maskedTextBox_Celular.Text = resultado["Celular"].ToString();
                    txt_Email.Text = resultado["Email"].ToString();
                    txt_Observacao.Text = resultado["Observacoes"].ToString();
                }
                ChecaBotoes();
                conexao.Close();
            }
            catch (MySqlException err)
            {
                MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0); 
            }
        }

        private void btn_Anterior_Click(object sender, EventArgs e)
        {
            MySqlConnection conexao = conectar.fazer_conexao();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = conexao;
            try
            {
                conexao.Open();
                cmd.CommandText = "Select * from clientes where Nome < '" + txt_Nome.Text + "' order by nome desc limit 1";
                MySqlDataReader resultado = cmd.ExecuteReader();
                if (resultado.HasRows)
                {
                    resultado.Read();
                    txt_ID.Text = resultado["ID_clientes"].ToString();
                    txt_Nome.Text = resultado["Nome"].ToString();
                    txt_Documento.Text = resultado["Documento"].ToString();
                    maskedTextBox_Data_de_Nascimento.Text = resultado["Data_de_Nascimento"].ToString();
                    txt_Endereco.Text = resultado["Endereco"].ToString();
                    txt_Bairro.Text = resultado["Bairro"].ToString();
                    txt_Cidade.Text = resultado["Cidade"].ToString();
                    txt_Estado.Text = resultado["Estado"].ToString();
                    txt_CEP.Text = resultado["CEP"].ToString();
                    maskedTextBox_Celular.Text = resultado["Celular"].ToString();
                    txt_Email.Text = resultado["Email"].ToString();
                    txt_Observacao.Text = resultado["Observacoes"].ToString();
                    
                }
                ChecaBotoes();
                conexao.Close();
            }
            catch (MySqlException err)
            {
                MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0); 
            }
        }

        private void Limpa_Campos()
        {
            txt_ID.Text = "";
            txt_Nome.Text = "";
            txt_Documento.Text = "";
            txt_Endereco.Text = "";
            txt_Bairro.Text = "";
            txt_Cidade.Text = "";
            txt_Estado.Text = "";
            txt_CEP.Text = ""; 
            txt_Email.Text = "";
            txt_Observacao.Text = "";
            maskedTextBox_Celular.Text = "";
            maskedTextBox_Data_de_Nascimento.Text = "";
        }
        
        

        private void ChecaBotoes()
        {
            MySqlConnection conexao = conectar.fazer_conexao(); 
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = conexao;
            try
            {
                conexao.Open();
                cmd.CommandText = "Select * from clientes order by Nome desc limit 1";
                MySqlDataReader resultado = cmd.ExecuteReader();
                if (resultado.HasRows)
                {
                    resultado.Read();
                    if (resultado["ID_clientes"].ToString() == txt_ID.Text)
                    {
                        btn_Proximo.Visible = false;
                    }
                    else
                    {
                        btn_Proximo.Visible = true;
                    }
                }
                resultado.Close();
                cmd.CommandText = "Select * from clientes order by Nome limit 1";
                resultado = cmd.ExecuteReader();
                if (resultado.HasRows)
                {
                    resultado.Read();
                    if (resultado["ID_clientes"].ToString() == txt_ID.Text)
                    {
                       btn_Anterior.Visible = false;
                    }
                    else
                    {
                       btn_Anterior.Visible = true;
                    }
                }
                conexao.Close();
            }
            catch (MySqlException err)
            {
                MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0); 
            }
        }

        private void Frm_Clientes_Load(object sender, EventArgs e)
        {
           
            txt_Nome.Focus();
            MySqlConnection conexao = conectar.fazer_conexao();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = conexao;
            try
            {
                conexao.Open();
                cmd.CommandText = "Select * from clientes order by Nome limit 1";
                MySqlDataReader resultado = cmd.ExecuteReader();
                if (resultado.HasRows)
                {
                    resultado.Read();
                    txt_ID.Text = resultado["ID_clientes"].ToString();
                    txt_Nome.Text = resultado["Nome"].ToString();
                    txt_Documento.Text = resultado["Documento"].ToString();
                    maskedTextBox_Data_de_Nascimento.Text = resultado["Data_de_Nascimento"].ToString();
                    txt_Endereco.Text = resultado["Endereco"].ToString();
                    txt_Bairro.Text = resultado["Bairro"].ToString();
                    txt_Cidade.Text = resultado["Cidade"].ToString();
                    txt_Estado.Text = resultado["Estado"].ToString();
                    txt_CEP.Text = resultado["CEP"].ToString();
                    maskedTextBox_Celular.Text = resultado["Celular"].ToString();
                    txt_Email.Text = resultado["Email"].ToString();
                    txt_Observacao.Text = resultado["Observacoes"].ToString();
                    ChecaBotoes();
                } 
                ChecaBotoes(); 
                conexao.Close();
            }
            catch (MySqlException err)
            {
                MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0);
            }
        }
    }
}