﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;


namespace Alberto_Gabriel
{
    public partial class Frm_OperacoesEmp : Form
    {
        public Frm_OperacoesEmp()
        {
            InitializeComponent();
        }
        private void ToolStripMenuItem_Emprestar_Jogos_Click(object sender, EventArgs e)
        {
            Limpa_Campos();
            dataGridView_Jogos.AllowUserToAddRows = false;
            MySqlConnection conexao = conectar.fazer_conexao();
            MySqlCommand cmd = new MySqlCommand();   
            cmd.Connection = conexao;
            try
            {
                conexao.Open();
                cmd.CommandText = "Select * from clientes order by Nome";
                MySqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        Escolher_Cliente.Items.Add(dr["Nome"].ToString());
                    }
                }
                dr.Close();
                conexao.Close();
                for (int i = 0; i <= dataGridView_Jogos.RowCount - 1; i++)
                {
                    conexao.Open();
                    cmd.CommandText = "select i.ID_Jogo, e.Data_de_Devolucao from itens_emprestimo i, emprestimos e where e.Data_de_Devolucao < 1 and i.ID_Emprestimo = e.ID";
                    MySqlDataReader read = cmd.ExecuteReader();
                    if (read.HasRows)
                    {
                        while (read.Read())
                        {
                            int id = int.Parse(read["ID_Jogo"].ToString());
                            if (Convert.ToInt32(dataGridView_Jogos.Rows[i].Cells[1].Value) == id)
                            {
                                CurrencyManager cm = (CurrencyManager)BindingContext[dataGridView_Jogos.DataSource];
                                cm.EndCurrentEdit();
                                cm.ResumeBinding();
                                cm.SuspendBinding();
                                dataGridView_Jogos.Rows[i].Visible = false;
                            }
                        }

                    }
                    conexao.Close();
                }
                ChecaBotoes();
            }
            catch (MySqlException err)
            {
                MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0);
            }
        }

        private void ToolStripMenuItem_Procurar_Empréstimo_Click(object sender, EventArgs e)
        {
            Frm_ProcurarEmp frm_ProcurarEmp = new Frm_ProcurarEmp();
            frm_ProcurarEmp.ShowDialog();
            if (conectar.nome_busca != "")
            {
                Escolher_Cliente.Items.Clear();
                MySqlConnection conexao = conectar.fazer_conexao();
                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = conexao;
                try
                {
                    conexao.Open();
                    cmd.CommandText = "Select c.ID_clientes, c.Nome, e.ID_Clientes, e.ID, e.Valor_Total_Locacao, e.Data_de_Locacao from emprestimos e, clientes c where  c.ID_clientes = e.ID_Clientes and c.Nome like '%" + conectar.nome_busca + "%' order by c.Nome desc limit 1";
                    MySqlDataReader resultado = cmd.ExecuteReader();
                    if (resultado.HasRows)
                    {
                        resultado.Read();
                        txt_ID_Operacoes.Text = resultado["ID"].ToString();
                        txt_Valor_Total.Text = "R$" + resultado["Valor_Total_Locacao"].ToString() + ",00";
                        maskedTextBox_Data_de_Locacao.Text = resultado["Data_de_Locacao"].ToString();
                        try
                        {
                            MySqlConnection conex = conectar.fazer_conexao();
                            conex.Open();
                            cmd.Connection = conex;
                            cmd.CommandText = "Select c.ID_clientes, c.Nome, e.ID_Clientes, e.ID from clientes c,emprestimos e where c.ID_clientes = e.ID_Clientes and e.ID = " + txt_ID_Operacoes.Text;
                            MySqlDataReader resp = cmd.ExecuteReader();
                            if (resp.HasRows)
                            {
                                while (resp.Read())
                                {
                                    Escolher_Cliente.Items.Add(resp["Nome"].ToString());
                                }
                            }
                            resp.Close();
                            conex.Close();
                        }
                        catch (MySqlException err)
                        {
                            MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            Environment.Exit(0);
                        }
                        try
                        {
                            MySqlConnection conex = conectar.fazer_conexao();
                            conex.Open();
                            string query = "Select i.ID_Emprestimo, i.ID_Jogo, j.Nome from itens_emprestimo i, jogos j where i.ID_Jogo = j.ID and i.ID_Emprestimo = " + txt_ID_Operacoes.Text;
                            MySqlDataAdapter res = new MySqlDataAdapter(query, conex);
                            DataTable dt = new DataTable();
                            res.Fill(dt);
                            dataGridView_Jogos.DataSource = dt;
                            conex.Close();
                        }
                        catch (MySqlException err)
                        {
                            MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            Environment.Exit(0);
                        }
                    }
                    else
                    {
                        MessageBox.Show("O empréstimo de " + conectar.nome_busca + " não foi encontrado", "Procurar : Empréstimos", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    ChecaBotoes();
                    conexao.Close();
                }
                catch (MySqlException err)
                {
                    MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Environment.Exit(0);
                }
            }
        }
        private void btn_Salvar_Click(object sender, EventArgs e)
        {
            MySqlConnection conexao = conectar.fazer_conexao();
            MySqlCommand cmd = new MySqlCommand();    
            cmd.Connection = conexao;
            
            if (Escolher_Cliente.SelectedIndex < 0 )
            {
                MessageBox.Show("Selecione o nome do cliente antes de prosseguir", "Salvar : Empréstimos", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Escolher_Cliente.Focus();
            }
            else
            {
                if (!maskedTextBox_Data_de_Locacao.MaskCompleted) 
                {
                     MessageBox.Show("Insira a data de locação antes de prosseguir", "Salvar : Empréstimos", MessageBoxButtons.OK, MessageBoxIcon.Error);
                     maskedTextBox_Data_de_Locacao.Focus();
                }
                else 
                { 
                try
                {
                    conexao.Open();
                    if(txt_ID_Operacoes.Text == "") 
                    {
                        int total_valor = 0;
                        for (int i = 0; i <= dataGridView_Jogos.RowCount - 1; i++)
                        {
                            Boolean calcula = Convert.ToBoolean(dataGridView_Jogos.Rows[i].Cells[0].Value);
                            if (calcula)
                            {
                                total_valor += 1;
                            }
                        }
                            total_valor *= 20;
                        txt_Valor_Total.Text = "R$" + total_valor.ToString() + ",00";
                       
                        cmd.CommandText = "Select c.ID_clientes from clientes c where c.Nome = '" + Escolher_Cliente.SelectedItem.ToString() + "' ";
                        MySqlDataReader resp = cmd.ExecuteReader();
                        resp.Read();
                        string id_cliente = resp["ID_clientes"].ToString(); resp.Close();
                        cmd.CommandText = "Insert into emprestimos (ID_Clientes, Data_de_Locacao, Valor_Total_Locacao) values ('" + id_cliente + "','" + maskedTextBox_Data_de_Locacao.Text + "','" + txt_Valor_Total.Text.Substring(2, txt_Valor_Total.Text.Length - 3 ) + "')";
                        cmd.ExecuteNonQuery(); 
                    }
                    conexao.Close();
                    conexao.Open();
                    string jogos = "", j = "";
                    for (int i = 0; i <= dataGridView_Jogos.RowCount - 1; i++)
                    {
                        if (Convert.ToBoolean(dataGridView_Jogos.Rows[i].Cells["select"].Value))
                        {
                             jogos = dataGridView_Jogos.Rows[i].Cells[1].Value.ToString();
                             j += "" + jogos + ", ";
                             cmd.CommandText = "Select MAX(ID) from emprestimos ";
                             MySqlDataReader resposta = cmd.ExecuteReader();
                             resposta.Read();
                             string ID_Operacao = resposta["MAX(ID)"].ToString(); resposta.Close();
                             cmd.CommandText = "Insert into itens_emprestimo (ID_Emprestimo, ID_Jogo) values ('" + ID_Operacao + "','" + jogos + "')";
                             cmd.ExecuteNonQuery();
                        }
                    }
                    MessageBox.Show("Empréstimo realizado com sucesso!", "Salvar : Empréstimos", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Gerar_PDF();
                    conexao.Close();  
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Erro: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }  
                } 
            }
        }
       
        private void btn_Cancelar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btn_Proximo_Click(object sender, EventArgs e)
        {
            Escolher_Cliente.Items.Clear();
            MySqlConnection conexao = conectar.fazer_conexao();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = conexao;
            try
            {
                conexao.Open();
                cmd.CommandText = "Select * from emprestimos where ID > '" + txt_ID_Operacoes.Text + "' order by ID limit 1";
                MySqlDataReader resultado = cmd.ExecuteReader();
                if (resultado.HasRows)
                {
                    resultado.Read();
                    txt_ID_Operacoes.Text = resultado["ID"].ToString();
                    txt_Valor_Total.Text = "R$" + resultado["Valor_Total_Locacao"].ToString() + ",00";
                    maskedTextBox_Data_de_Locacao.Text = resultado["Data_de_Locacao"].ToString();
                    try
                    {
                        MySqlConnection conex = conectar.fazer_conexao();
                        conex.Open();
                        cmd.Connection = conex;
                        cmd.CommandText = "Select c.ID_clientes, c.Nome, e.ID_Clientes, e.ID from clientes c,emprestimos e where c.ID_clientes = e.ID_Clientes and e.ID = " + txt_ID_Operacoes.Text;
                        MySqlDataReader resp = cmd.ExecuteReader();
                        if (resp.HasRows)
                        {
                            while (resp.Read())
                            {
                                Escolher_Cliente.Items.Add(resp["Nome"].ToString());
                            }
                        }
                        resp.Close();
                        conex.Close();
                    }
                    catch (MySqlException err)
                    {
                        MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        Environment.Exit(0);
                    }
                    try
                    {
                        MySqlConnection conex = conectar.fazer_conexao();
                        conex.Open();
                        string query = "Select i.ID_Emprestimo, i.ID_Jogo, j.Nome from itens_emprestimo i, jogos j where i.ID_Jogo = j.ID and i.ID_Emprestimo = " + txt_ID_Operacoes.Text;
                        MySqlDataAdapter res = new MySqlDataAdapter(query, conex);
                        DataTable dt = new DataTable();
                        res.Fill(dt);
                        dataGridView_Jogos.DataSource = dt;
                        conex.Close();
                    }
                    catch (MySqlException err)
                    {
                        MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        Environment.Exit(0);
                    }
                }
                ChecaBotoes();
                conexao.Close();
            }
            catch (MySqlException err)
            {
                MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0);
            }
        }

        private void btn_Anterior_Click(object sender, EventArgs e)
        {
            Escolher_Cliente.Items.Clear();
            MySqlConnection conexao = conectar.fazer_conexao();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = conexao;
            try
            {
                conexao.Open();
                cmd.CommandText = "Select * from emprestimos where ID < '" + txt_ID_Operacoes.Text + "' order by ID desc limit 1";
                MySqlDataReader resultado = cmd.ExecuteReader();
                if (resultado.HasRows)
                {
                    resultado.Read();
                    txt_ID_Operacoes.Text = resultado["ID"].ToString();
                    txt_Valor_Total.Text = "R$" + resultado["Valor_Total_Locacao"].ToString() + ",00";
                    maskedTextBox_Data_de_Locacao.Text = resultado["Data_de_Locacao"].ToString();
                    try
                    {
                        MySqlConnection conex = conectar.fazer_conexao();
                        conex.Open();
                        cmd.Connection = conex;
                        cmd.CommandText = "Select c.ID_clientes, c.Nome, e.ID_Clientes, e.ID from clientes c,emprestimos e where c.ID_clientes = e.ID_Clientes and e.ID = " + txt_ID_Operacoes.Text;
                        MySqlDataReader resp = cmd.ExecuteReader();
                        if (resp.HasRows)
                        {
                            while (resp.Read())
                            {
                                Escolher_Cliente.Items.Add(resp["Nome"].ToString());
                            }
                        }
                        resp.Close();
                        conex.Close();
                    }
                    catch (MySqlException err)
                    {
                        MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        Environment.Exit(0);
                    }
                    try
                    {
                        MySqlConnection conex = conectar.fazer_conexao();
                        conex.Open();
                        string query = "Select i.ID_Emprestimo, i.ID_Jogo, j.Nome from itens_emprestimo i, jogos j where i.ID_Jogo = j.ID and i.ID_Emprestimo = " + txt_ID_Operacoes.Text;
                        MySqlDataAdapter res = new MySqlDataAdapter(query, conex);
                        DataTable dt = new DataTable();
                        res.Fill(dt);
                        dataGridView_Jogos.DataSource = dt;
                        conex.Close();
                    }
                    catch (MySqlException err)
                    {
                        MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        Environment.Exit(0);
                    }
                }
                ChecaBotoes();
                conexao.Close();
            }
            catch (MySqlException err)
            {
                MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0);
            }
        }

        private void Limpa_Campos()
        {
            txt_ID_Operacoes.Text = "";
            Escolher_Cliente.Text = "";
            maskedTextBox_Data_de_Locacao.Text = "";
            txt_Valor_Total.Text = "";
            Escolher_Cliente.Items.Clear();
            try
            {
                MySqlConnection conexao = conectar.fazer_conexao();
                conexao.Open();
                string query = "Select ID, Genero, Nome from jogos order by ID";
                MySqlDataAdapter resultado = new MySqlDataAdapter(query, conexao);
                DataTable dt = new DataTable();
                resultado.Fill(dt);
                dataGridView_Jogos.DataSource = dt;
                conexao.Close();
            }
            catch (MySqlException err)
            {
                MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0);
            }
        }

        private void ChecaBotoes()
        {
            MySqlConnection conexao = conectar.fazer_conexao();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = conexao;
            try
            {
                conexao.Open();
                cmd.CommandText = "Select * from emprestimos order by ID desc limit 1";
                MySqlDataReader resultado = cmd.ExecuteReader();
                if (resultado.HasRows)
                {
                    resultado.Read();
                    if (resultado["ID"].ToString() == txt_ID_Operacoes.Text)
                    {
                        btn_Proximo.Visible = false;
                    }
                    else
                    {
                        btn_Proximo.Visible = true;
                    }
                }
                resultado.Close();
                cmd.CommandText = "Select * from emprestimos order by ID limit 1";
                resultado = cmd.ExecuteReader();
                if (resultado.HasRows)
                {
                    resultado.Read();
                    if (resultado["ID"].ToString() == txt_ID_Operacoes.Text)
                    {
                        btn_Anterior.Visible = false;
                    }
                    else
                    {
                        btn_Anterior.Visible = true;
                    }
                }
                conexao.Close();
            }
            catch (MySqlException err)
            {
                MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0);
            }
        }

        private void Frm_OperacoesEmp_Load(object sender, EventArgs e)
        {
            dataGridView_Jogos.AllowUserToAddRows = false;
            Escolher_Cliente.Items.Clear();
            MySqlConnection conexao = conectar.fazer_conexao(); 
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = conexao;
            try
            {
                conexao.Open();
                cmd.CommandText = "Select c.ID_clientes, c.Nome, e.ID_Clientes, e.ID, e.Valor_Total_Locacao, e.Data_de_Locacao from emprestimos e, clientes c where c.ID_clientes = e.ID_Clientes order by c.Nome desc limit 1";
                MySqlDataReader resultado = cmd.ExecuteReader();
                if (resultado.HasRows)
                {
                    resultado.Read();
                    txt_ID_Operacoes.Text = resultado["ID"].ToString();
                    txt_Valor_Total.Text = "R$" + resultado["Valor_Total_Locacao"].ToString() + ",00";
                    maskedTextBox_Data_de_Locacao.Text = resultado["Data_de_Locacao"].ToString();
                    try
                    {
                        MySqlConnection conex = conectar.fazer_conexao();
                        conex.Open();
                        cmd.Connection = conex;
                        cmd.CommandText = "Select c.ID_clientes, c.Nome, e.ID_Clientes, e.ID from clientes c,emprestimos e where c.ID_clientes = e.ID_Clientes and e.ID = " + txt_ID_Operacoes.Text;
                        MySqlDataReader dr = cmd.ExecuteReader();
                        if (dr.HasRows)
                        {  
                            while (dr.Read())
                            {
                                Escolher_Cliente.Items.Add(dr["Nome"].ToString());
                            }
                        }
                        dr.Close();
                        conex.Close();
                    }
                    catch (MySqlException err)
                    {
                        MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        Environment.Exit(0);
                    }
                    try
                    {
                        MySqlConnection conex = conectar.fazer_conexao();
                        conex.Open();
                        string query = "Select i.ID_Emprestimo, i.ID_Jogo, j.Nome from itens_emprestimo i, jogos j where i.ID_Jogo = j.ID and i.ID_Emprestimo = " + txt_ID_Operacoes.Text;
                        MySqlDataAdapter res = new MySqlDataAdapter(query, conex);
                        DataTable dt = new DataTable();
                        res.Fill(dt);
                        dataGridView_Jogos.DataSource = dt;
                        conex.Close();
                        }
                    catch (MySqlException err)
                    {
                        MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        Environment.Exit(0);
                    }
                }
                ChecaBotoes();
                conexao.Close();
            }
            catch (MySqlException err)
            {
                MessageBox.Show(err.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0);
            }
        }
       
        private void Gerar_PDF()
        {
            DateTime data = Convert.ToDateTime(maskedTextBox_Data_de_Locacao.Text);
            data = data.AddDays(2);
            string jogos = "";
            for (int i = 0; i <= dataGridView_Jogos.RowCount - 1; i++)
            {
                if (Convert.ToBoolean(dataGridView_Jogos.Rows[i].Cells["select"].Value))
                {
                    jogos += dataGridView_Jogos.Rows[i].Cells[3].Value + ", ";
                }
            }
            txt_Valor_Total.Text.Substring(0, txt_Valor_Total.Text.Length - 3);
            string arquivoPDF = @"C:\Users\deadg\OneDrive\Documentos\Arquivos PDF\Relatorio_Locadora_Emprestimos.pdf";
            Document doc = new Document();
            FileStream fs = new FileStream(arquivoPDF, FileMode.Create, FileAccess.Write, FileShare.None);
            PdfWriter.GetInstance(doc, fs);
            doc.Open();
            doc.SetMargins(40, 40, 40, 60);

            iTextSharp.text.pdf.draw.VerticalPositionMark seperator = new iTextSharp.text.pdf.draw.LineSeparator();

            var FonteColor = new BaseColor(242, 100, 25);
            var MFont = FontFactory.GetFont("Times New Roman", 17);
            var FonteBase = BaseFont.CreateFont(BaseFont.TIMES_ROMAN, BaseFont.CP1252, false);
            var FonteSubTitulo = new iTextSharp.text.Font(FonteBase, 15, iTextSharp.text.Font.BOLD, BaseColor.BLACK);
            var FonteParagrafo = new iTextSharp.text.Font(FonteBase, 13, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);
            var FonteCabecalho = new iTextSharp.text.Font(FonteBase, 10, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);
            Paragraph cabecalho = new Paragraph("", FonteCabecalho);
            cabecalho.Add("UEMG – Universidade do Estado de Minas Gerais – Unidade Frutal\nCurso – Sistema de Informação, 4º Período, Noturno\nDisciplina – Programaçao II \nDocente – Sérgio Portari\nDiscente – Alberto Oliveira Batista\nTrabalho - Desenvolvimento de Sistema de Locadora");
            doc.Add(cabecalho);
            doc.Add(new Paragraph(Environment.NewLine));
            doc.Add(seperator);
            Paragraph titulo = new Paragraph("", MFont);
            titulo.Alignment = Element.ALIGN_CENTER;
            titulo.Add("LOCADORA DE JOGOS");
            doc.Add(titulo);
            doc.Add(new Paragraph(Environment.NewLine));
            doc.Add(new Paragraph("Relatório de Empréstimo", FonteSubTitulo));
            Paragraph paragrafo = new Paragraph("", FonteParagrafo);
            paragrafo.Add(Environment.NewLine);
            paragrafo.Add("ID Empréstimo: " + txt_ID_Operacoes.Text + Environment.NewLine);
            paragrafo.Add("Nome: " + Escolher_Cliente.Text + Environment.NewLine);
            paragrafo.Add("Data de Locação: " + maskedTextBox_Data_de_Locacao.Text + Environment.NewLine);
            paragrafo.Add("Data de Devolução Prevista: " + data.ToShortDateString() + Environment.NewLine);
            paragrafo.Add("Valor Total Locação: " + txt_Valor_Total.Text + Environment.NewLine);
            paragrafo.Add("Jogos Alocados: " + jogos + Environment.NewLine);
            doc.Add(paragrafo);
            doc.Add(new Paragraph(Environment.NewLine));
            doc.Add(seperator);
            doc.Close();
            MessageBox.Show("Impressão concluída", "Imprimir : Empréstimos", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void ToolStripMenuItem_Imp_Emprestimo_Click(object sender, EventArgs e)
        {
            Gerar_PDF();
        }
    }
    
}

