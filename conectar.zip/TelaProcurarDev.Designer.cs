﻿namespace Alberto_Gabriel
{
    partial class Frm_ProcurarDev
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_ProcurarDev));
            this.groupBoxProcurarDev = new System.Windows.Forms.GroupBox();
            this.btn_Cancelar_Dev = new System.Windows.Forms.Button();
            this.btn_Procurar_Dev = new System.Windows.Forms.Button();
            this.txt_Procurar_Dev = new System.Windows.Forms.TextBox();
            this.lbl_Procurar_Dev = new System.Windows.Forms.Label();
            this.groupBoxProcurarDev.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxProcurarDev
            // 
            this.groupBoxProcurarDev.Controls.Add(this.btn_Cancelar_Dev);
            this.groupBoxProcurarDev.Controls.Add(this.btn_Procurar_Dev);
            this.groupBoxProcurarDev.Controls.Add(this.txt_Procurar_Dev);
            this.groupBoxProcurarDev.Controls.Add(this.lbl_Procurar_Dev);
            this.groupBoxProcurarDev.Location = new System.Drawing.Point(12, 14);
            this.groupBoxProcurarDev.Name = "groupBoxProcurarDev";
            this.groupBoxProcurarDev.Size = new System.Drawing.Size(407, 135);
            this.groupBoxProcurarDev.TabIndex = 4;
            this.groupBoxProcurarDev.TabStop = false;
            // 
            // btn_Cancelar_Dev
            // 
            this.btn_Cancelar_Dev.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_Cancelar_Dev.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(100)))), ((int)(((byte)(25)))));
            this.btn_Cancelar_Dev.Location = new System.Drawing.Point(217, 106);
            this.btn_Cancelar_Dev.Name = "btn_Cancelar_Dev";
            this.btn_Cancelar_Dev.Size = new System.Drawing.Size(89, 23);
            this.btn_Cancelar_Dev.TabIndex = 7;
            this.btn_Cancelar_Dev.Text = "Cancelar";
            this.btn_Cancelar_Dev.UseVisualStyleBackColor = true;
            this.btn_Cancelar_Dev.Click += new System.EventHandler(this.btn_Cancelar_Dev_Click);
            // 
            // btn_Procurar_Dev
            // 
            this.btn_Procurar_Dev.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_Procurar_Dev.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(100)))), ((int)(((byte)(25)))));
            this.btn_Procurar_Dev.Location = new System.Drawing.Point(312, 106);
            this.btn_Procurar_Dev.Name = "btn_Procurar_Dev";
            this.btn_Procurar_Dev.Size = new System.Drawing.Size(89, 23);
            this.btn_Procurar_Dev.TabIndex = 6;
            this.btn_Procurar_Dev.Text = "Procurar";
            this.btn_Procurar_Dev.UseVisualStyleBackColor = true;
            this.btn_Procurar_Dev.Click += new System.EventHandler(this.btn_Procurar_Dev_Click);
            // 
            // txt_Procurar_Dev
            // 
            this.txt_Procurar_Dev.Location = new System.Drawing.Point(9, 32);
            this.txt_Procurar_Dev.Name = "txt_Procurar_Dev";
            this.txt_Procurar_Dev.Size = new System.Drawing.Size(392, 20);
            this.txt_Procurar_Dev.TabIndex = 5;
            // 
            // lbl_Procurar_Dev
            // 
            this.lbl_Procurar_Dev.AutoSize = true;
            this.lbl_Procurar_Dev.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Procurar_Dev.Location = new System.Drawing.Point(6, 16);
            this.lbl_Procurar_Dev.Name = "lbl_Procurar_Dev";
            this.lbl_Procurar_Dev.Size = new System.Drawing.Size(126, 16);
            this.lbl_Procurar_Dev.TabIndex = 4;
            this.lbl_Procurar_Dev.Text = "Nome do Cliente:";
            // 
            // Frm_ProcurarDev
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(431, 163);
            this.Controls.Add(this.groupBoxProcurarDev);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Frm_ProcurarDev";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Locadora : Devoluções : Procurar";
            this.groupBoxProcurarDev.ResumeLayout(false);
            this.groupBoxProcurarDev.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxProcurarDev;
        private System.Windows.Forms.Button btn_Cancelar_Dev;
        private System.Windows.Forms.Button btn_Procurar_Dev;
        private System.Windows.Forms.TextBox txt_Procurar_Dev;
        private System.Windows.Forms.Label lbl_Procurar_Dev;
    }
}