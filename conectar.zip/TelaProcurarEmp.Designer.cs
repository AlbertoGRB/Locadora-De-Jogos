﻿namespace Alberto_Gabriel
{
    partial class Frm_ProcurarEmp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_ProcurarEmp));
            this.groupBox_Procurar_Emp = new System.Windows.Forms.GroupBox();
            this.btn_Cancelar_Emp = new System.Windows.Forms.Button();
            this.btn_Procurar_Emp = new System.Windows.Forms.Button();
            this.txt_Procurar_Emp = new System.Windows.Forms.TextBox();
            this.lbl_Procurar_Emp = new System.Windows.Forms.Label();
            this.groupBox_Procurar_Emp.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox_Procurar_Emp
            // 
            this.groupBox_Procurar_Emp.Controls.Add(this.btn_Cancelar_Emp);
            this.groupBox_Procurar_Emp.Controls.Add(this.btn_Procurar_Emp);
            this.groupBox_Procurar_Emp.Controls.Add(this.txt_Procurar_Emp);
            this.groupBox_Procurar_Emp.Controls.Add(this.lbl_Procurar_Emp);
            this.groupBox_Procurar_Emp.Location = new System.Drawing.Point(12, 14);
            this.groupBox_Procurar_Emp.Name = "groupBox_Procurar_Emp";
            this.groupBox_Procurar_Emp.Size = new System.Drawing.Size(407, 135);
            this.groupBox_Procurar_Emp.TabIndex = 3;
            this.groupBox_Procurar_Emp.TabStop = false;
            // 
            // btn_Cancelar_Emp
            // 
            this.btn_Cancelar_Emp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_Cancelar_Emp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(100)))), ((int)(((byte)(25)))));
            this.btn_Cancelar_Emp.Location = new System.Drawing.Point(219, 106);
            this.btn_Cancelar_Emp.Name = "btn_Cancelar_Emp";
            this.btn_Cancelar_Emp.Size = new System.Drawing.Size(88, 23);
            this.btn_Cancelar_Emp.TabIndex = 7;
            this.btn_Cancelar_Emp.Text = "Cancelar";
            this.btn_Cancelar_Emp.UseVisualStyleBackColor = true;
            this.btn_Cancelar_Emp.Click += new System.EventHandler(this.btn_Cancelar_Emp_Click);
            // 
            // btn_Procurar_Emp
            // 
            this.btn_Procurar_Emp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_Procurar_Emp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(100)))), ((int)(((byte)(25)))));
            this.btn_Procurar_Emp.Location = new System.Drawing.Point(313, 106);
            this.btn_Procurar_Emp.Name = "btn_Procurar_Emp";
            this.btn_Procurar_Emp.Size = new System.Drawing.Size(88, 23);
            this.btn_Procurar_Emp.TabIndex = 6;
            this.btn_Procurar_Emp.Text = "Procurar";
            this.btn_Procurar_Emp.UseVisualStyleBackColor = true;
            this.btn_Procurar_Emp.Click += new System.EventHandler(this.btn_Procurar_Emp_Click);
            // 
            // txt_Procurar_Emp
            // 
            this.txt_Procurar_Emp.Location = new System.Drawing.Point(9, 32);
            this.txt_Procurar_Emp.Name = "txt_Procurar_Emp";
            this.txt_Procurar_Emp.Size = new System.Drawing.Size(392, 20);
            this.txt_Procurar_Emp.TabIndex = 5;
            // 
            // lbl_Procurar_Emp
            // 
            this.lbl_Procurar_Emp.AutoSize = true;
            this.lbl_Procurar_Emp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Procurar_Emp.Location = new System.Drawing.Point(6, 16);
            this.lbl_Procurar_Emp.Name = "lbl_Procurar_Emp";
            this.lbl_Procurar_Emp.Size = new System.Drawing.Size(126, 16);
            this.lbl_Procurar_Emp.TabIndex = 4;
            this.lbl_Procurar_Emp.Text = "Nome do Cliente:";
            // 
            // Frm_ProcurarEmp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(431, 163);
            this.Controls.Add(this.groupBox_Procurar_Emp);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Frm_ProcurarEmp";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Locadora : Empréstimos : Procurar";
            this.groupBox_Procurar_Emp.ResumeLayout(false);
            this.groupBox_Procurar_Emp.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox_Procurar_Emp;
        private System.Windows.Forms.Button btn_Cancelar_Emp;
        private System.Windows.Forms.Button btn_Procurar_Emp;
        private System.Windows.Forms.TextBox txt_Procurar_Emp;
        private System.Windows.Forms.Label lbl_Procurar_Emp;
    }
}