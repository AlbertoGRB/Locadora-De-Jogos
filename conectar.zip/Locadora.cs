﻿using System;
using System.Windows.Forms;

namespace Alberto_Gabriel
{
    public partial class Frm_Locadora : Form
    {
        public Frm_Locadora()
        {
            InitializeComponent();
        }

        private void toolStripTextBoxClientes_Click(object sender, EventArgs e)
        {
            for (int Index = Application.OpenForms.Count - 1; Index >= 0; Index--) 
            {
                    if (Application.OpenForms[Index] != this) 
                    Application.OpenForms[Index].Close(); 
            }
            Frm_Clientes clientes = new Frm_Clientes();
            clientes.MdiParent = this;
            clientes.Show();
        }

        public void toolStripTextBoxGeneros_Click(object sender, EventArgs e)
        {

            for (int Index = Application.OpenForms.Count - 1; Index >= 0; Index--)
            {
                if (Application.OpenForms[Index] != this)
                    Application.OpenForms[Index].Close();
            }
            Frm_Generos generos = new Frm_Generos();
            generos.MdiParent = this;
            generos.Show();
        }
        
        private void toolStripTextBoxJogos_Click(object sender, EventArgs e)
        {
            for (int Index = Application.OpenForms.Count - 1; Index >= 0; Index--)
            {
                if (Application.OpenForms[Index] != this)
                    Application.OpenForms[Index].Close();
            }
            Frm_Jogos jogos = new Frm_Jogos();
            jogos.MdiParent = this;
            jogos.Show();
        }
      
       
        private void ToolStripMenuItemEmpréstimos_Click(object sender, EventArgs e)
        {   for (int Index = Application.OpenForms.Count - 1; Index >= 0; Index--)
            {
                if (Application.OpenForms[Index] != this)
                    Application.OpenForms[Index].Close();
            }
            Frm_OperacoesEmp operacoesEmp = new Frm_OperacoesEmp();
            operacoesEmp.MdiParent = this;
            operacoesEmp.Show();
        }

        private void ToolStripMenuItemDevoluções_Click(object sender, EventArgs e)
        {   for (int Index = Application.OpenForms.Count - 1; Index >= 0; Index--)
            {
                if (Application.OpenForms[Index] != this)
                    Application.OpenForms[Index].Close();
            }
            Frm_OperacoesDev operacoesDev = new Frm_OperacoesDev();
            operacoesDev.MdiParent = this;
            operacoesDev.Show();
        }
        
        private void toolStripTextBoxSair_Click(object sender, EventArgs e)
        {
            DialogResult resultado = MessageBox.Show("Tem certeza de que deseja sair?", "Sair", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (resultado == DialogResult.Yes)
            {
                Close();
            }
            // Se o usuário clicar em "Não", o programa não será fechado
        }

        private void Frm_Locadora_Load(object sender, EventArgs e)
        {

        }
    }
}
